"use client"

import type React from "react"
import { createContext, useContext, useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Cookies from "js-cookie"
import axios from "axios"

export type AuthStatus = "authenticated" | "unauthenticated" | "loading"

export interface User {
  id: string
  name: string
  email: string
  username: string
  profilePicture?: string
  role?: string
}

interface AuthContextType {
  user: User | null
  status: AuthStatus
  signIn: (email: string, password: string) => Promise<void>
  signUp: (userData: RegisterData) => Promise<void>
  verifyOTP: (email: string, otp: string) => Promise<void>
  resendOTP: (email: string) => Promise<void>
  signOut: () => Promise<void>
  forgotPassword: (email: string) => Promise<void>
  resetPassword: (email: string, token: string, password: string) => Promise<void>
}

export interface RegisterData {
  name: string
  email: string
  username: string
  password: string
  birthday: Date
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000/api"

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [status, setStatus] = useState<AuthStatus>("loading")
  const router = useRouter()

  // Check if user is logged in on mount
  useEffect(() => {
    const checkAuth = async () => {
      try {
        const token = Cookies.get("authToken")

        if (!token) {
          setStatus("unauthenticated")
          return
        }

        const response = await axios.get(`${API_URL}/auth/me`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        })

        if (response.data.success) {
          setUser(response.data.data.user)
          setStatus("authenticated")
        } else {
          Cookies.remove("authToken")
          setStatus("unauthenticated")
        }
      } catch (error) {
        console.error("Authentication check failed:", error)
        Cookies.remove("authToken")
        setStatus("unauthenticated")
      }
    }

    checkAuth()
  }, [])

  const signIn = async (email: string, password: string) => {
    try {
      const response = await axios.post(`${API_URL}/auth/login`, {
        email,
        password,
      })

      if (response.data.success) {
        const { token, user } = response.data.data

        // Store token in cookies
        Cookies.set("authToken", token, { expires: 7 }) // 7 days

        // Update state
        setUser(user)
        setStatus("authenticated")

        // Redirect to feed
        router.push("/feed")
      } else {
        throw new Error(response.data.message || "Login failed")
      }
    } catch (error: any) {
      console.error("Authentication error:", error)
      throw new Error(error.response?.data?.message || error.message || "Login failed")
    }
  }

  const signUp = async (userData: RegisterData) => {
    try {
      const response = await axios.post(`${API_URL}/auth/register`, userData)

      if (response.data.success) {
        // Registration successful, but user needs to verify OTP
        router.push(`/verify-otp?email=${encodeURIComponent(userData.email)}`)
      } else {
        throw new Error(response.data.message || "Registration failed")
      }
    } catch (error: any) {
      console.error("Registration error:", error)
      throw new Error(error.response?.data?.message || error.message || "Registration failed")
    }
  }

  const verifyOTP = async (email: string, otp: string) => {
    try {
      const response = await axios.post(`${API_URL}/auth/verify-otp`, {
        email,
        otp,
      })

      if (response.data.success) {
        const { token, user } = response.data.data

        // Store token in cookies
        Cookies.set("authToken", token, { expires: 7 }) // 7 days

        // Update state
        setUser(user)
        setStatus("authenticated")

        // Redirect to feed
        router.push("/feed")
      } else {
        throw new Error(response.data.message || "OTP verification failed")
      }
    } catch (error: any) {
      console.error("OTP verification error:", error)
      throw new Error(error.response?.data?.message || error.message || "OTP verification failed")
    }
  }

  const resendOTP = async (email: string) => {
    try {
      const response = await axios.post(`${API_URL}/auth/resend-otp`, {
        email,
      })

      if (!response.data.success) {
        throw new Error(response.data.message || "Failed to resend OTP")
      }
    } catch (error: any) {
      console.error("Resend OTP error:", error)
      throw new Error(error.response?.data?.message || error.message || "Failed to resend OTP")
    }
  }

  const signOut = async () => {
    try {
      const token = Cookies.get("authToken")

      if (token) {
        await axios.post(
          `${API_URL}/auth/logout`,
          {},
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          },
        )
      }
    } catch (error) {
      console.error("Sign out error:", error)
    } finally {
      // Remove token and update state regardless of API call success
      Cookies.remove("authToken")
      setUser(null)
      setStatus("unauthenticated")
      router.push("/login")
    }
  }

  const forgotPassword = async (email: string) => {
    try {
      const response = await axios.post(`${API_URL}/auth/forgot-password`, {
        email,
      })

      if (!response.data.success) {
        throw new Error(response.data.message || "Failed to send reset email")
      }
    } catch (error: any) {
      console.error("Forgot password error:", error)
      throw new Error(error.response?.data?.message || error.message || "Failed to send reset email")
    }
  }

  const resetPassword = async (email: string, token: string, password: string) => {
    try {
      const response = await axios.post(`${API_URL}/auth/reset-password`, {
        email,
        token,
        password,
      })

      if (!response.data.success) {
        throw new Error(response.data.message || "Failed to reset password")
      }
    } catch (error: any) {
      console.error("Reset password error:", error)
      throw new Error(error.response?.data?.message || error.message || "Failed to reset password")
    }
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        status,
        signIn,
        signUp,
        verifyOTP,
        resendOTP,
        signOut,
        forgotPassword,
        resetPassword,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}


import express from "express"
import { asyncHandler } from "../utils/asyncHandler.js"
import { verifyToken } from "../middleware/auth.js"
import {
  getNotifications,
  getUnreadNotificationsCount,
  markNotificationAsRead,
  markAllNotificationsAsRead,
  deleteNotification,
  deleteAllNotifications,
  updateNotificationSettings,
} from "../controllers/notificationController.js"

const router = express.Router()

// All routes require authentication
router.use(verifyToken)

router.get("/", asyncHandler(getNotifications))
router.get("/unread/count", asyncHandler(getUnreadNotificationsCount))
router.put("/:id/read", asyncHandler(markNotificationAsRead))
router.put("/read-all", asyncHandler(markAllNotificationsAsRead))
router.delete("/:id", asyncHandler(deleteNotification))
router.delete("/", asyncHandler(deleteAllNotifications))
router.put("/settings", asyncHandler(updateNotificationSettings))

export default router


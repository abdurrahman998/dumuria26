import Joi from "joi"

// User validation schemas
export const registerSchema = Joi.object({
  username: Joi.string().alphanum().min(3).max(30).required(),
  email: Joi.string().email().required(),
  name: Joi.string().min(2).max(50).required(),
  birthday: Joi.date().max("now").required(),
  password: Joi.string().min(8).required(),
  confirmPassword: Joi.string().valid(Joi.ref("password")).required(),
})

export const loginSchema = Joi.object({
  email: Joi.string().email().required(),
  password: Joi.string().required(),
})

export const updateUserSchema = Joi.object({
  name: Joi.string().min(2).max(50),
  bio: Joi.string().max(500).allow(""),
  location: Joi.string().max(100).allow(""),
  website: Joi.string().uri().allow(""),
  profilePicture: Joi.string().allow(""),
  coverPhoto: Joi.string().allow(""),
  notifications: Joi.object({
    likes: Joi.boolean(),
    comments: Joi.boolean(),
    follows: Joi.boolean(),
    messages: Joi.boolean(),
  }),
})

// Post validation schemas
export const createPostSchema = Joi.object({
  content: Joi.string().max(5000).required(),
  media: Joi.array().items(
    Joi.object({
      type: Joi.string().valid("image", "video", "gif").required(),
      url: Joi.string().required(),
      alt: Joi.string().allow(""),
    }),
  ),
  tags: Joi.array().items(Joi.string().trim()),
  location: Joi.object({
    name: Joi.string(),
    coordinates: Joi.object({
      latitude: Joi.number(),
      longitude: Joi.number(),
    }),
  }),
  visibility: Joi.string().valid("public", "followers", "private"),
  poll: Joi.object({
    question: Joi.string().required(),
    options: Joi.array()
      .min(2)
      .max(4)
      .items(
        Joi.object({
          text: Joi.string().required(),
        }),
      )
      .required(),
    expiresAt: Joi.date().greater("now"),
  }),
  mentions: Joi.array().items(
    Joi.object({
      user: Joi.string().required(),
      startIndex: Joi.number().required(),
      endIndex: Joi.number().required(),
    }),
  ),
})

export const updatePostSchema = Joi.object({
  content: Joi.string().max(5000),
  tags: Joi.array().items(Joi.string().trim()),
  visibility: Joi.string().valid("public", "followers", "private"),
  isPinned: Joi.boolean(),
})

// Comment validation schemas
export const createCommentSchema = Joi.object({
  content: Joi.string().max(1000).required(),
  parentComment: Joi.string().allow(null),
  media: Joi.object({
    type: Joi.string().valid("image", "gif"),
    url: Joi.string(),
    alt: Joi.string().allow(""),
  }),
  mentions: Joi.array().items(
    Joi.object({
      user: Joi.string().required(),
      startIndex: Joi.number().required(),
      endIndex: Joi.number().required(),
    }),
  ),
})

export const updateCommentSchema = Joi.object({
  content: Joi.string().max(1000).required(),
})

// Message validation schemas
export const createMessageSchema = Joi.object({
  content: Joi.string()
    .max(5000)
    .when("media", {
      is: Joi.exist(),
      then: Joi.optional(),
      otherwise: Joi.required(),
    })
    .when("voiceMessage", {
      is: Joi.exist(),
      then: Joi.optional(),
      otherwise: Joi.required(),
    }),
  media: Joi.object({
    type: Joi.string().valid("image", "video", "gif", "file").required(),
    url: Joi.string().required(),
    fileName: Joi.string(),
    fileSize: Joi.number(),
    mimeType: Joi.string(),
  }),
  voiceMessage: Joi.object({
    url: Joi.string().required(),
    duration: Joi.number().required(),
  }),
  replyTo: Joi.string(),
  expiresAt: Joi.date().greater("now"),
})

// Conversation validation schemas
export const createConversationSchema = Joi.object({
  participants: Joi.array().min(1).items(Joi.string()).required(),
  isGroup: Joi.boolean().default(false),
  groupName: Joi.when("isGroup", {
    is: true,
    then: Joi.string().required(),
    otherwise: Joi.optional(),
  }),
  groupImage: Joi.string().allow(""),
})

export const updateConversationSchema = Joi.object({
  groupName: Joi.string(),
  groupImage: Joi.string().allow(""),
  isPinned: Joi.boolean(),
})


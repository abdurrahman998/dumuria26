"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { Edit, Search, CheckCheck, MoreHorizontal, Pin, VolumeX, Trash, Archive } from "lucide-react"
import { Icons } from "@/components/icons"
import { getConversations } from "@/lib/data"
import { formatDistanceToNow } from "date-fns"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

interface MessageListProps extends React.HTMLAttributes<HTMLDivElement> {
  activeId?: string
}

export function MessageList({ className, activeId }: MessageListProps) {
  const [conversations, setConversations] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const pathname = usePathname()

  useEffect(() => {
    const fetchConversations = async () => {
      setLoading(true)
      try {
        const data = await getConversations()

        // Add additional properties to conversations
        const enhancedData = data.map((conv: any) => ({
          ...conv,
          unreadCount: Math.floor(Math.random() * 5), // Simulate random unread counts
          isPinned: conv.id === "conversation-1", // Pin the first conversation for demo
          lastMessageStatus:
            conv.lastMessage.senderId === "user-1" ? (Math.random() > 0.5 ? "seen" : "delivered") : undefined,
        }))

        setConversations(enhancedData)
      } catch (error) {
        console.error("Error fetching conversations:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchConversations()
  }, [])

  // Sort conversations: pinned first, then by last message timestamp
  const sortedConversations = [...conversations].sort((a, b) => {
    // Pinned conversations first
    if (a.isPinned && !b.isPinned) return -1
    if (!a.isPinned && b.isPinned) return 1

    // Then by last message timestamp (newest first)
    return new Date(b.lastMessage.timestamp).getTime() - new Date(a.lastMessage.timestamp).getTime()
  })

  const filteredConversations = sortedConversations.filter(
    (conversation) =>
      conversation.participant.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      conversation.lastMessage.content.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handlePinConversation = (id: string) => {
    setConversations((prev) => prev.map((conv) => (conv.id === id ? { ...conv, isPinned: !conv.isPinned } : conv)))
  }

  const handleArchiveConversation = (id: string) => {
    // In a real app, we would call an API to archive the conversation
    setConversations((prev) => prev.filter((conv) => conv.id !== id))
  }

  const handleDeleteConversation = (id: string) => {
    // In a real app, we would call an API to delete the conversation
    setConversations((prev) => prev.filter((conv) => conv.id !== id))
  }

  const handleMuteConversation = (id: string) => {
    // In a real app, we would call an API to mute the conversation
    setConversations((prev) => prev.map((conv) => (conv.id === id ? { ...conv, isMuted: !conv.isMuted } : conv)))
  }

  const getMessageStatusIcon = (status?: "sent" | "delivered" | "seen") => {
    switch (status) {
      case "delivered":
        return <CheckCheck className="h-3 w-3 text-muted-foreground" />
      case "seen":
        return <CheckCheck className="h-3 w-3 text-blue-500" />
      default:
        return null
    }
  }

  return (
    <div className={cn("flex h-full flex-col", className)}>
      <div className="p-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold">Messages</h2>
          <Button variant="ghost" size="icon" className="rounded-full">
            <Edit className="h-5 w-5" />
            <span className="sr-only">New message</span>
          </Button>
        </div>
        <div className="relative mt-4">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search messages"
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>
      <ScrollArea className="flex-1 p-4">
        {loading ? (
          <div className="flex justify-center p-4">
            <Icons.spinner className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : filteredConversations.length === 0 ? (
          <div className="p-4 text-center text-muted-foreground">
            {searchQuery ? "No conversations found" : "No messages yet"}
          </div>
        ) : (
          <div className="space-y-2">
            {filteredConversations.map((conversation) => (
              <div key={conversation.id} className="relative">
                <Link
                  href={`/messages/${conversation.id}`}
                  className={cn(
                    "flex items-center space-x-4 rounded-lg p-3 transition-colors hover:bg-accent",
                    (activeId === conversation.id || pathname === `/messages/${conversation.id}`) && "bg-accent",
                  )}
                >
                  <div className="relative">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={conversation.participant.avatar} alt={conversation.participant.name} />
                      <AvatarFallback>{conversation.participant.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <span
                      className={cn(
                        "absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-background",
                        conversation.participant.isOnline ? "bg-green-500" : "bg-gray-400",
                      )}
                    />
                  </div>
                  <div className="flex-1 space-y-1">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <p className="font-medium">{conversation.participant.name}</p>
                        {conversation.isPinned && <Pin className="ml-1 h-3 w-3 text-muted-foreground" />}
                        {conversation.isMuted && <VolumeX className="ml-1 h-3 w-3 text-muted-foreground" />}
                      </div>
                      <span className="text-xs text-muted-foreground flex items-center">
                        {formatDistanceToNow(new Date(conversation.lastMessage.timestamp), { addSuffix: true })}
                        {conversation.lastMessage.senderId === "user-1" && (
                          <span className="ml-1">{getMessageStatusIcon(conversation.lastMessageStatus)}</span>
                        )}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <p className="line-clamp-1 text-sm text-muted-foreground">
                        {conversation.lastMessage.senderId === "user-1" && "You: "}
                        {conversation.lastMessage.content}
                      </p>
                      {conversation.unreadCount > 0 && (
                        <Badge variant="default" className="ml-2 px-1.5 py-0.5 rounded-full">
                          {conversation.unreadCount}
                        </Badge>
                      )}
                    </div>
                  </div>
                </Link>

                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="absolute right-2 top-2 h-8 w-8 p-0 rounded-full opacity-0 group-hover:opacity-100 hover:opacity-100 focus:opacity-100"
                    >
                      <MoreHorizontal className="h-4 w-4" />
                      <span className="sr-only">More options</span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem
                      onClick={(e) => {
                        e.preventDefault()
                        e.stopPropagation()
                        handlePinConversation(conversation.id)
                      }}
                    >
                      <Pin className="mr-2 h-4 w-4" />
                      {conversation.isPinned ? "Unpin conversation" : "Pin conversation"}
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      onClick={(e) => {
                        e.preventDefault()
                        e.stopPropagation()
                        handleMuteConversation(conversation.id)
                      }}
                    >
                      <VolumeX className="mr-2 h-4 w-4" />
                      {conversation.isMuted ? "Unmute conversation" : "Mute conversation"}
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      onClick={(e) => {
                        e.preventDefault()
                        e.stopPropagation()
                        handleArchiveConversation(conversation.id)
                      }}
                    >
                      <Archive className="mr-2 h-4 w-4" />
                      Archive conversation
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem
                      onClick={(e) => {
                        e.preventDefault()
                        e.stopPropagation()
                        handleDeleteConversation(conversation.id)
                      }}
                      className="text-red-500 focus:text-red-500"
                    >
                      <Trash className="mr-2 h-4 w-4" />
                      Delete conversation
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            ))}
          </div>
        )}
      </ScrollArea>
    </div>
  )
}


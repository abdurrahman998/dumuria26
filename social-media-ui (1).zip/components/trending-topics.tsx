"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Hash } from "lucide-react"
import Link from "next/link"

interface TrendingTopicsProps {
  searchable?: boolean
  onTagClick?: (tag: string) => void
}

export function TrendingTopics({ searchable = false, onTagClick }: TrendingTopicsProps) {
  const trendingTopics = [
    {
      id: 1,
      tag: "Technology",
      posts: 1234,
    },
    {
      id: 2,
      tag: "Design",
      posts: 987,
    },
    {
      id: 3,
      tag: "Programming",
      posts: 876,
    },
    {
      id: 4,
      tag: "AI",
      posts: 765,
    },
    {
      id: 5,
      tag: "WebDev",
      posts: 654,
    },
  ]

  return (
    <Card>
      <CardHeader>
        <CardTitle>Trending Topics</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {trendingTopics.map((topic) => (
            <div key={topic.id} className="flex items-center justify-between">
              {searchable && onTagClick ? (
                <button className="flex items-center space-x-2" onClick={() => onTagClick(topic.tag)}>
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-muted">
                    <Hash className="h-4 w-4" />
                  </div>
                  <div>
                    <p className="font-medium">#{topic.tag}</p>
                    <p className="text-xs text-muted-foreground">{topic.posts} posts</p>
                  </div>
                </button>
              ) : (
                <Link
                  href={`/search?q=${encodeURIComponent(topic.tag)}&category=hashtags`}
                  className="flex items-center space-x-2"
                >
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-muted">
                    <Hash className="h-4 w-4" />
                  </div>
                  <div>
                    <p className="font-medium">#{topic.tag}</p>
                    <p className="text-xs text-muted-foreground">{topic.posts} posts</p>
                  </div>
                </Link>
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}


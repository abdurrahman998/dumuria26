import Post from "../models/Post.js"
import User from "../models/User.js"
import Comment from "../models/Comment.js"
import Notification from "../models/Notification.js"
import { ApiError } from "../utils/ApiError.js"
import { asyncHandler } from "../utils/asyncHandler.js"
import { processImage, getFileUrl, deleteFile } from "../utils/fileUpload.js"
import path from "path"
import mongoose from "mongoose"

/**
 * @desc    Create a new post
 * @route   POST /api/posts
 * @access  Private
 */
export const createPost = asyncHandler(async (req, res) => {
  const { content, tags = [], location, visibility = "public", poll, mentions = [] } = req.body

  // Validate content
  if (!content && (!req.files || req.files.length === 0)) {
    throw new ApiError(400, "Post must have content or media")
  }

  try {
    // Create new post
    const newPost = new Post({
      user: req.user._id,
      content,
      tags: Array.isArray(tags) ? tags : tags.split(",").map((tag) => tag.trim()),
      location,
      visibility,
      poll: poll ? JSON.parse(poll) : undefined,
      mentions: Array.isArray(mentions) ? mentions : JSON.parse(mentions),
    })

    // Handle media uploads if files are provided
    if (req.files && req.files.length > 0) {
      const mediaPromises = req.files.map(async (file) => {
        const fileType = file.mimetype.startsWith("image/")
          ? "image"
          : file.mimetype.startsWith("video/")
            ? "video"
            : "gif"

        // Process image files (resize, optimize)
        if (fileType === "image" && file.mimetype !== "image/gif") {
          await processImage(file.path)
        }

        return {
          type: fileType,
          url: getFileUrl(file.path),
          alt: file.originalname,
        }
      })

      newPost.media = await Promise.all(mediaPromises)
    }

    // Save post
    await newPost.save()

    // Populate user data
    const populatedPost = await Post.findById(newPost._id)
      .populate("user", "username name profilePicture")
      .populate({
        path: "comments",
        options: { limit: 2, sort: { createdAt: -1 } },
        populate: {
          path: "user",
          select: "username name profilePicture",
        },
      })

    // Create notifications for mentioned users
    if (mentions && mentions.length > 0) {
      const notificationPromises = mentions.map((mention) => {
        return new Notification({
          recipient: mention.user,
          sender: req.user._id,
          type: "mention",
          post: newPost._id,
          content: `${req.user.name} mentioned you in a post`,
        }).save()
      })

      await Promise.all(notificationPromises)
    }

    res.status(201).json({
      success: true,
      message: "Post created successfully",
      data: populatedPost,
    })
  } catch (error) {
    // Delete uploaded files if post creation fails
    if (req.files && req.files.length > 0) {
      req.files.forEach((file) => {
        deleteFile(file.path)
      })
    }

    throw new ApiError(500, "Error creating post", [error.message])
  }
})

/**
 * @desc    Get all posts for feed
 * @route   GET /api/posts/feed
 * @access  Private
 */
export const getFeedPosts = asyncHandler(async (req, res) => {
  const { page = 1, limit = 10 } = req.query
  const skip = (Number.parseInt(page) - 1) * Number.parseInt(limit)

  // Get IDs of users the current user is following
  const currentUser = await User.findById(req.user._id)
  const followingIds = currentUser.following || []

  // Include current user's posts in feed
  const userIds = [...followingIds, req.user._id]

  // Find posts from followed users and current user
  const posts = await Post.find({
    user: { $in: userIds },
    visibility: { $in: ["public", "followers"] },
  })
    .sort({ createdAt: -1 })
    .skip(skip)
    .limit(Number.parseInt(limit))
    .populate("user", "username name profilePicture")
    .populate({
      path: "comments",
      options: { limit: 2, sort: { createdAt: -1 } },
      populate: {
        path: "user",
        select: "username name profilePicture",
      },
    })

  // Get total count for pagination
  const total = await Post.countDocuments({
    user: { $in: userIds },
    visibility: { $in: ["public", "followers"] },
  })

  res.status(200).json({
    success: true,
    data: {
      posts,
      pagination: {
        total,
        page: Number.parseInt(page),
        pages: Math.ceil(total / Number.parseInt(limit)),
      },
    },
  })
})

/**
 * @desc    Get post by ID
 * @route   GET /api/posts/:id
 * @access  Public/Private (depends on post visibility)
 */
export const getPostById = asyncHandler(async (req, res) => {
  const { id } = req.params

  if (!mongoose.Types.ObjectId.isValid(id)) {
    throw new ApiError(400, "Invalid post ID")
  }

  const post = await Post.findById(id)
    .populate("user", "username name profilePicture")
    .populate({
      path: "comments",
      populate: {
        path: "user",
        select: "username name profilePicture",
      },
    })

  if (!post) {
    throw new ApiError(404, "Post not found")
  }

  // Check if post is private and user is not the owner
  if (post.visibility === "private" && (!req.user || post.user._id.toString() !== req.user._id.toString())) {
    throw new ApiError(403, "You do not have permission to view this post")
  }

  // Check if post is for followers only and user is not following
  if (post.visibility === "followers" && req.user) {
    const postOwner = await User.findById(post.user._id)
    const isFollowing = postOwner.followers.includes(req.user._id)

    if (!isFollowing && post.user._id.toString() !== req.user._id.toString()) {
      throw new ApiError(403, "You must follow this user to view this post")
    }
  }

  res.status(200).json({
    success: true,
    data: post,
  })
})

/**
 * @desc    Update post
 * @route   PUT /api/posts/:id
 * @access  Private
 */
export const updatePost = asyncHandler(async (req, res) => {
  const { id } = req.params
  const { content, tags, location, visibility } = req.body

  if (!mongoose.Types.ObjectId.isValid(id)) {
    throw new ApiError(400, "Invalid post ID")
  }

  const post = await Post.findById(id)

  if (!post) {
    throw new ApiError(404, "Post not found")
  }

  // Check if user is the post owner
  if (post.user.toString() !== req.user._id.toString()) {
    throw new ApiError(403, "You do not have permission to update this post")
  }

  // Update post fields
  if (content !== undefined) post.content = content
  if (tags !== undefined) {
    post.tags = Array.isArray(tags) ? tags : tags.split(",").map((tag) => tag.trim())
  }
  if (location !== undefined) post.location = location
  if (visibility !== undefined) post.visibility = visibility

  // Mark as edited
  post.isEdited = true
  post.updatedAt = Date.now()

  await post.save()

  // Populate user data
  const updatedPost = await Post.findById(id)
    .populate("user", "username name profilePicture")
    .populate({
      path: "comments",
      options: { limit: 2, sort: { createdAt: -1 } },
      populate: {
        path: "user",
        select: "username name profilePicture",
      },
    })

  res.status(200).json({
    success: true,
    message: "Post updated successfully",
    data: updatedPost,
  })
})

/**
 * @desc    Delete post
 * @route   DELETE /api/posts/:id
 * @access  Private
 */
export const deletePost = asyncHandler(async (req, res) => {
  const { id } = req.params

  if (!mongoose.Types.ObjectId.isValid(id)) {
    throw new ApiError(400, "Invalid post ID")
  }

  const post = await Post.findById(id)

  if (!post) {
    throw new ApiError(404, "Post not found")
  }

  // Check if user is the post owner or an admin
  if (post.user.toString() !== req.user._id.toString() && req.user.role !== "admin") {
    throw new ApiError(403, "You do not have permission to delete this post")
  }

  // Delete media files from storage
  if (post.media && post.media.length > 0) {
    post.media.forEach((media) => {
      try {
        // Extract file path from URL
        const urlParts = new URL(media.url)
        const filePath = path.join(process.cwd(), urlParts.pathname)
        deleteFile(filePath)
      } catch (error) {
        console.error("Error deleting media file:", error)
      }
    })
  }

  // Delete all comments associated with the post
  await Comment.deleteMany({ post: id })

  // Delete all notifications related to this post
  await Notification.deleteMany({ post: id })

  // Delete post
  await Post.findByIdAndDelete(id)

  res.status(200).json({
    success: true,
    message: "Post deleted successfully",
  })
})

/**
 * @desc    Like post
 * @route   POST /api/posts/:id/like
 * @access  Private
 */
export const likePost = asyncHandler(async (req, res) => {
  const { id } = req.params

  if (!mongoose.Types.ObjectId.isValid(id)) {
    throw new ApiError(400, "Invalid post ID")
  }

  const post = await Post.findById(id)

  if (!post) {
    throw new ApiError(404, "Post not found")
  }

  // Check if user already liked the post
  if (post.likes.includes(req.user._id)) {
    return res.status(200).json({
      success: true,
      message: "Post already liked",
      data: post,
    })
  }

  // Add user to likes array
  post.likes.push(req.user._id)
  await post.save()

  // Create notification for post owner
  if (post.user.toString() !== req.user._id.toString()) {
    await new Notification({
      recipient: post.user,
      sender: req.user._id,
      type: "like",
      post: post._id,
      content: `${req.user.name} liked your post`,
    }).save()
  }

  res.status(200).json({
    success: true,
    message: "Post liked successfully",
    data: post,
  })
})

/**
 * @desc    Unlike post
 * @route   POST /api/posts/:id/unlike
 * @access  Private
 */
export const unlikePost = asyncHandler(async (req, res) => {
  const { id } = req.params

  if (!mongoose.Types.ObjectId.isValid(id)) {
    throw new ApiError(400, "Invalid post ID")
  }

  const post = await Post.findById(id)

  if (!post) {
    throw new ApiError(404, "Post not found")
  }

  // Check if user has liked the post
  if (!post.likes.includes(req.user._id)) {
    return res.status(200).json({
      success: true,
      message: "Post not liked",
      data: post,
    })
  }

  // Remove user from likes array
  post.likes = post.likes.filter((userId) => userId.toString() !== req.user._id.toString())
  await post.save()

  // Remove like notification
  await Notification.deleteOne({
    recipient: post.user,
    sender: req.user._id,
    type: "like",
    post: post._id,
  })

  res.status(200).json({
    success: true,
    message: "Post unliked successfully",
    data: post,
  })
})

/**
 * @desc    Get user posts
 * @route   GET /api/posts/user/:userId
 * @access  Public/Private (depends on post visibility)
 */
export const getUserPosts = asyncHandler(async (req, res) => {
  const { userId } = req.params
  const { page = 1, limit = 10 } = req.query
  const skip = (Number.parseInt(page) - 1) * Number.parseInt(limit)

  if (!mongoose.Types.ObjectId.isValid(userId)) {
    throw new ApiError(400, "Invalid user ID")
  }

  const user = await User.findById(userId)

  if (!user) {
    throw new ApiError(404, "User not found")
  }

  // Determine which posts to show based on visibility and relationship
  let visibilityFilter = { visibility: "public" }

  if (req.user) {
    if (req.user._id.toString() === userId) {
      // User viewing their own posts - show all
      visibilityFilter = {}
    } else if (user.followers.includes(req.user._id)) {
      // User is a follower - show public and followers-only posts
      visibilityFilter = { visibility: { $in: ["public", "followers"] } }
    }
  }

  // Find posts
  const posts = await Post.find({
    user: userId,
    ...visibilityFilter,
  })
    .sort({ createdAt: -1 })
    .skip(skip)
    .limit(Number.parseInt(limit))
    .populate("user", "username name profilePicture")
    .populate({
      path: "comments",
      options: { limit: 2, sort: { createdAt: -1 } },
      populate: {
        path: "user",
        select: "username name profilePicture",
      },
    })

  // Get total count for pagination
  const total = await Post.countDocuments({
    user: userId,
    ...visibilityFilter,
  })

  res.status(200).json({
    success: true,
    data: {
      posts,
      pagination: {
        total,
        page: Number.parseInt(page),
        pages: Math.ceil(total / Number.parseInt(limit)),
      },
    },
  })
})

/**
 * @desc    Save post
 * @route   POST /api/posts/:id/save
 * @access  Private
 */
export const savePost = asyncHandler(async (req, res) => {
  const { id } = req.params

  if (!mongoose.Types.ObjectId.isValid(id)) {
    throw new ApiError(400, "Invalid post ID")
  }

  const post = await Post.findById(id)

  if (!post) {
    throw new ApiError(404, "Post not found")
  }

  const user = await User.findById(req.user._id)

  // Check if post is already saved
  if (user.savedPosts.includes(id)) {
    return res.status(200).json({
      success: true,
      message: "Post already saved",
      data: user.savedPosts,
    })
  }

  // Add post to saved posts
  user.savedPosts.push(id)
  await user.save()

  res.status(200).json({
    success: true,
    message: "Post saved successfully",
    data: user.savedPosts,
  })
})

/**
 * @desc    Unsave post
 * @route   POST /api/posts/:id/unsave
 * @access  Private
 */
export const unsavePost = asyncHandler(async (req, res) => {
  const { id } = req.params

  if (!mongoose.Types.ObjectId.isValid(id)) {
    throw new ApiError(400, "Invalid post ID")
  }

  const user = await User.findById(req.user._id)

  // Check if post is saved
  if (!user.savedPosts.includes(id)) {
    return res.status(200).json({
      success: true,
      message: "Post not saved",
      data: user.savedPosts,
    })
  }

  // Remove post from saved posts
  user.savedPosts = user.savedPosts.filter((postId) => postId.toString() !== id)
  await user.save()

  res.status(200).json({
    success: true,
    message: "Post unsaved successfully",
    data: user.savedPosts,
  })
})

/**
 * @desc    Get saved posts
 * @route   GET /api/posts/saved
 * @access  Private
 */
export const getSavedPosts = asyncHandler(async (req, res) => {
  const { page = 1, limit = 10 } = req.query
  const skip = (Number.parseInt(page) - 1) * Number.parseInt(limit)

  const user = await User.findById(req.user._id)

  // Find saved posts
  const posts = await Post.find({
    _id: { $in: user.savedPosts },
  })
    .sort({ createdAt: -1 })
    .skip(skip)
    .limit(Number.parseInt(limit))
    .populate("user", "username name profilePicture")
    .populate({
      path: "comments",
      options: { limit: 2, sort: { createdAt: -1 } },
      populate: {
        path: "user",
        select: "username name profilePicture",
      },
    })

  // Get total count for pagination
  const total = user.savedPosts.length

  res.status(200).json({
    success: true,
    data: {
      posts,
      pagination: {
        total,
        page: Number.parseInt(page),
        pages: Math.ceil(total / Number.parseInt(limit)),
      },
    },
  })
})

/**
 * @desc    Report post
 * @route   POST /api/posts/:id/report
 * @access  Private
 */
export const reportPost = asyncHandler(async (req, res) => {
  const { id } = req.params
  const { reason } = req.body

  if (!mongoose.Types.ObjectId.isValid(id)) {
    throw new ApiError(400, "Invalid post ID")
  }

  if (!reason) {
    throw new ApiError(400, "Reason is required")
  }

  const post = await Post.findById(id)

  if (!post) {
    throw new ApiError(404, "Post not found")
  }

  // In a real app, save report to a reports collection
  // For now, we'll just add a report to the post
  if (!post.reports) {
    post.reports = []
  }

  // Check if user already reported this post
  const alreadyReported = post.reports.some((report) => report.user.toString() === req.user._id.toString())

  if (alreadyReported) {
    throw new ApiError(400, "You have already reported this post")
  }

  post.reports.push({
    user: req.user._id,
    reason,
    createdAt: Date.now(),
  })

  await post.save()

  // Notify admins (in a real app)
  // ...

  res.status(200).json({
    success: true,
    message: "Post reported successfully",
  })
})

/**
 * @desc    Search posts
 * @route   GET /api/posts/search
 * @access  Public/Private (depends on post visibility)
 */
export const searchPosts = asyncHandler(async (req, res) => {
  const { q, tags, page = 1, limit = 10 } = req.query
  const skip = (Number.parseInt(page) - 1) * Number.parseInt(limit)

  const query = {}

  // Text search if query provided
  if (q) {
    query.$text = { $search: q }
  }

  // Filter by tags if provided
  if (tags) {
    const tagArray = tags.split(",").map((tag) => tag.trim())
    query.tags = { $in: tagArray }
  }

  // Only show public posts for non-authenticated users
  if (!req.user) {
    query.visibility = "public"
  } else {
    // For authenticated users, show public posts and followers-only posts from followed users
    const currentUser = await User.findById(req.user._id)
    query.$or = [
      { visibility: "public" },
      {
        visibility: "followers",
        user: { $in: currentUser.following },
      },
      {
        user: req.user._id,
      },
    ]
  }

  // Find posts
  const posts = await Post.find(query)
    .sort({ score: { $meta: "textScore" }, createdAt: -1 })
    .skip(skip)
    .limit(Number.parseInt(limit))
    .populate("user", "username name profilePicture")
    .populate({
      path: "comments",
      options: { limit: 2, sort: { createdAt: -1 } },
      populate: {
        path: "user",
        select: "username name profilePicture",
      },
    })

  // Get total count for pagination
  const total = await Post.countDocuments(query)

  res.status(200).json({
    success: true,
    data: {
      posts,
      pagination: {
        total,
        page: Number.parseInt(page),
        pages: Math.ceil(total / Number.parseInt(limit)),
      },
    },
  })
})

/**
 * @desc    Get trending posts
 * @route   GET /api/posts/trending
 * @access  Public
 */
export const getTrendingPosts = asyncHandler(async (req, res) => {
  const { page = 1, limit = 10 } = req.query
  const skip = (Number.parseInt(page) - 1) * Number.parseInt(limit)

  // Calculate trending score based on likes, comments, and recency
  // This is a simplified algorithm - in production, use a more sophisticated approach
  const trendingPosts = await Post.aggregate([
    {
      $match: {
        visibility: "public",
        createdAt: { $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) }, // Last 7 days
      },
    },
    {
      $addFields: {
        likesCount: { $size: "$likes" },
        commentsCount: { $size: "$comments" },
        // Calculate hours since post creation
        hoursSinceCreated: {
          $divide: [{ $subtract: [new Date(), "$createdAt"] }, 1000 * 60 * 60],
        },
      },
    },
    {
      $addFields: {
        // Simple trending score formula
        trendingScore: {
          $divide: [
            { $add: ["$likesCount", { $multiply: ["$commentsCount", 2] }] },
            { $pow: [{ $add: ["$hoursSinceCreated", 2] }, 1.5] },
          ],
        },
      },
    },
    { $sort: { trendingScore: -1 } },
    { $skip: skip },
    { $limit: Number.parseInt(limit) },
  ])

  // Get post details
  const postIds = trendingPosts.map((post) => post._id)
  const posts = await Post.find({ _id: { $in: postIds } })
    .populate("user", "username name profilePicture")
    .populate({
      path: "comments",
      options: { limit: 2, sort: { createdAt: -1 } },
      populate: {
        path: "user",
        select: "username name profilePicture",
      },
    })

  // Sort posts by trending score
  posts.sort((a, b) => {
    const aScore = trendingPosts.find((p) => p._id.toString() === a._id.toString()).trendingScore
    const bScore = trendingPosts.find((p) => p._id.toString() === b._id.toString()).trendingScore
    return bScore - aScore
  })

  // Get total count for pagination
  const total = await Post.countDocuments({
    visibility: "public",
    createdAt: { $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) },
  })

  res.status(200).json({
    success: true,
    data: {
      posts,
      pagination: {
        total,
        page: Number.parseInt(page),
        pages: Math.ceil(total / Number.parseInt(limit)),
      },
    },
  })
})

/**
 * @desc    Add comment to post
 * @route   POST /api/posts/:id/comments
 * @access  Private
 */
export const addComment = asyncHandler(async (req, res) => {
  const { id } = req.params
  const { content } = req.body

  if (!mongoose.Types.ObjectId.isValid(id)) {
    throw new ApiError(400, "Invalid post ID")
  }

  if (!content) {
    throw new ApiError(400, "Comment content is required")
  }

  const post = await Post.findById(id)

  if (!post) {
    throw new ApiError(404, "Post not found")
  }

  // Create new comment
  const comment = new Comment({
    user: req.user._id,
    post: id,
    content,
  })

  await comment.save()

  // Add comment to post
  post.comments.push(comment._id)
  await post.save()

  // Populate user data
  const populatedComment = await Comment.findById(comment._id).populate("user", "username name profilePicture")

  // Create notification for post owner if it's not the same user
  if (post.user.toString() !== req.user._id.toString()) {
    await new Notification({
      recipient: post.user,
      sender: req.user._id,
      type: "comment",
      post: post._id,
      comment: comment._id,
      content: `${req.user.name} commented on your post`,
    }).save()
  }

  res.status(201).json({
    success: true,
    message: "Comment added successfully",
    data: populatedComment,
  })
})

/**
 * @desc    Get comments for a post
 * @route   GET /api/posts/:id/comments
 * @access  Public/Private (depends on post visibility)
 */
export const getPostComments = asyncHandler(async (req, res) => {
  const { id } = req.params
  const { page = 1, limit = 10 } = req.query
  const skip = (Number.parseInt(page) - 1) * Number.parseInt(limit)

  if (!mongoose.Types.ObjectId.isValid(id)) {
    throw new ApiError(400, "Invalid post ID")
  }

  const post = await Post.findById(id)

  if (!post) {
    throw new ApiError(404, "Post not found")
  }

  // Check post visibility
  if (post.visibility === "private" && (!req.user || post.user.toString() !== req.user._id.toString())) {
    throw new ApiError(403, "You do not have permission to view this post's comments")
  }

  if (post.visibility === "followers" && req.user) {
    const postOwner = await User.findById(post.user)
    const isFollowing = postOwner.followers.includes(req.user._id)

    if (!isFollowing && post.user.toString() !== req.user._id.toString()) {
      throw new ApiError(403, "You must follow this user to view this post's comments")
    }
  }

  // Get comments
  const comments = await Comment.find({ post: id })
    .sort({ createdAt: -1 })
    .skip(skip)
    .limit(Number.parseInt(limit))
    .populate("user", "username name profilePicture")
    .populate("likes", "username name profilePicture")

  // Get total count for pagination
  const total = await Comment.countDocuments({ post: id })

  res.status(200).json({
    success: true,
    data: {
      comments,
      pagination: {
        total,
        page: Number.parseInt(page),
        pages: Math.ceil(total / Number.parseInt(limit)),
      },
    },
  })
})

/**
 * @desc    Vote on poll
 * @route   POST /api/posts/:id/poll/:optionId
 * @access  Private
 */
export const voteOnPoll = asyncHandler(async (req, res) => {
  const { id, optionId } = req.params

  if (!mongoose.Types.ObjectId.isValid(id)) {
    throw new ApiError(400, "Invalid post ID")
  }

  const post = await Post.findById(id)

  if (!post) {
    throw new ApiError(404, "Post not found")
  }

  if (!post.poll || !post.poll.options) {
    throw new ApiError(400, "Post does not have a poll")
  }

  // Check if poll has expired
  if (post.poll.expiresAt && new Date() > new Date(post.poll.expiresAt)) {
    throw new ApiError(400, "Poll has expired")
  }

  // Find the option
  const optionIndex = post.poll.options.findIndex((option) => option._id.toString() === optionId)

  if (optionIndex === -1) {
    throw new ApiError(404, "Poll option not found")
  }

  // Check if user has already voted
  const hasVoted = post.poll.options.some((option) => option.votes.includes(req.user._id))

  if (hasVoted) {
    // Remove previous vote
    post.poll.options.forEach((option) => {
      option.votes = option.votes.filter((userId) => userId.toString() !== req.user._id.toString())
    })
  }

  // Add vote to selected option
  post.poll.options[optionIndex].votes.push(req.user._id)

  await post.save()

  res.status(200).json({
    success: true,
    message: "Vote recorded successfully",
    data: post.poll,
  })
})

/**
 * @desc    Get posts by tag
 * @route   GET /api/posts/tags/:tag
 * @access  Public
 */
export const getPostsByTag = asyncHandler(async (req, res) => {
  const { tag } = req.params
  const { page = 1, limit = 10 } = req.query
  const skip = (Number.parseInt(page) - 1) * Number.parseInt(limit)

  // Prepare query
  const query = {
    tags: tag,
    // Only show public posts for non-authenticated users
    visibility: !req.user ? "public" : { $in: ["public", "followers"] },
  }

  // If user is authenticated, also show posts from users they follow
  if (req.user) {
    const currentUser = await User.findById(req.user._id)
    query.$or = [
      { visibility: "public" },
      {
        visibility: "followers",
        user: { $in: currentUser.following },
      },
      {
        user: req.user._id,
      },
    ]
  }

  // Find posts
  const posts = await Post.find(query)
    .sort({ createdAt: -1 })
    .skip(skip)
    .limit(Number.parseInt(limit))
    .populate("user", "username name profilePicture")
    .populate({
      path: "comments",
      options: { limit: 2, sort: { createdAt: -1 } },
      populate: {
        path: "user",
        select: "username name profilePicture",
      },
    })

  // Get total count for pagination
  const total = await Post.countDocuments(query)

  res.status(200).json({
    success: true,
    data: {
      posts,
      pagination: {
        total,
        page: Number.parseInt(page),
        pages: Math.ceil(total / Number.parseInt(limit)),
      },
    },
  })
})

/**
 * @desc    Get trending tags
 * @route   GET /api/posts/trending-tags
 * @access  Public
 */
export const getTrendingTags = asyncHandler(async (req, res) => {
  // Get posts from the last 7 days
  const recentPosts = await Post.find({
    visibility: "public",
    createdAt: { $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) },
  })

  // Count tag occurrences
  const tagCounts = {}
  recentPosts.forEach((post) => {
    if (post.tags && post.tags.length > 0) {
      post.tags.forEach((tag) => {
        if (tagCounts[tag]) {
          tagCounts[tag]++
        } else {
          tagCounts[tag] = 1
        }
      })
    }
  })

  // Convert to array and sort
  const trendingTags = Object.keys(tagCounts)
    .map((tag) => ({
      name: tag,
      count: tagCounts[tag],
    }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 10)

  res.status(200).json({
    success: true,
    data: trendingTags,
  })
})

/**
 * @desc    Share post
 * @route   POST /api/posts/:id/share
 * @access  Private
 */
export const sharePost = asyncHandler(async (req, res) => {
  const { id } = req.params
  const { content } = req.body

  if (!mongoose.Types.ObjectId.isValid(id)) {
    throw new ApiError(400, "Invalid post ID")
  }

  const originalPost = await Post.findById(id)

  if (!originalPost) {
    throw new ApiError(404, "Post not found")
  }

  // Check if original post is public
  if (originalPost.visibility !== "public") {
    throw new ApiError(403, "You can only share public posts")
  }

  // Create new post as a share
  const newPost = new Post({
    user: req.user._id,
    content: content || "",
    sharedPost: id,
    visibility: "public", // Shares are always public
  })

  await newPost.save()

  // Increment share count on original post
  originalPost.shareCount = (originalPost.shareCount || 0) + 1
  await originalPost.save()

  // Create notification for original post owner
  if (originalPost.user.toString() !== req.user._id.toString()) {
    await new Notification({
      recipient: originalPost.user,
      sender: req.user._id,
      type: "share",
      post: originalPost._id,
      content: `${req.user.name} shared your post`,
    }).save()
  }

  // Populate user data
  const populatedPost = await Post.findById(newPost._id)
    .populate("user", "username name profilePicture")
    .populate({
      path: "sharedPost",
      populate: {
        path: "user",
        select: "username name profilePicture",
      },
    })

  res.status(201).json({
    success: true,
    message: "Post shared successfully",
    data: populatedPost,
  })
})

/**
 * @desc    Get post analytics
 * @route   GET /api/posts/:id/analytics
 * @access  Private (post owner only)
 */
export const getPostAnalytics = asyncHandler(async (req, res) => {
  const { id } = req.params

  if (!mongoose.Types.ObjectId.isValid(id)) {
    throw new ApiError(400, "Invalid post ID")
  }

  const post = await Post.findById(id)

  if (!post) {
    throw new ApiError(404, "Post not found")
  }

  // Check if user is the post owner
  if (post.user.toString() !== req.user._id.toString()) {
    throw new ApiError(403, "You can only view analytics for your own posts")
  }

  // Get analytics data
  const analytics = {
    likes: post.likes.length,
    comments: post.comments.length,
    shares: post.shareCount || 0,
    views: post.viewCount || 0,
    engagement: calculateEngagement(post),
    // Add more analytics as needed
  }

  res.status(200).json({
    success: true,
    data: analytics,
  })
})

// Helper function to calculate engagement rate
const calculateEngagement = (post) => {
  const interactions = post.likes.length + post.comments.length + (post.shareCount || 0)
  const views = post.viewCount || interactions // If no view count, use interactions as baseline
  return (interactions / views) * 100
}

export default {
  createPost,
  getFeedPosts,
  getPostById,
  updatePost,
  deletePost,
  likePost,
  unlikePost,
  getUserPosts,
  savePost,
  unsavePost,
  getSavedPosts,
  reportPost,
  searchPosts,
  getTrendingPosts,
  voteOnPoll,
  getPostsByTag,
  getTrendingTags,
  sharePost,
  getPostAnalytics,
  addComment,
  getPostComments,
}


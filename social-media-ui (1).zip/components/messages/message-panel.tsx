"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { cn } from "@/lib/utils"
import {
  Paperclip,
  Send,
  Smile,
  Clock,
  MoreHorizontal,
  Check,
  CheckCheck,
  Trash,
  Reply,
  Forward,
  Edit,
  Ban,
  Flag,
  VideoIcon,
  GiftIcon as Gif,
  Timer,
  X,
  Mic,
  FileText,
  Play,
  Volume2,
  Search,
  ArrowLeft,
} from "lucide-react"
import { Icons } from "@/components/icons"
import { getMessages } from "@/lib/data"
import { EmojiPicker } from "@/components/post/emoji-picker"
import { GifPicker } from "@/components/post/gif-picker"
import { format } from "date-fns"
import { useRouter } from "next/navigation"

interface MessagePanelProps extends React.HTMLAttributes<HTMLDivElement> {
  conversation?: any
}

interface Message {
  id: string
  content: string
  timestamp: string
  senderId: string
  isRead: boolean
  status?: "sent" | "delivered" | "seen"
  replyTo?: string
  media?: {
    type: "image" | "video" | "audio" | "gif"
    url: string
  }[]
  reactions?: {
    emoji: string
    userId: string
  }[]
  isEdited?: boolean
  expiresAt?: string
}

export function MessagePanel({ className, conversation }: MessagePanelProps) {
  const [messages, setMessages] = useState<Message[]>([])
  const [loading, setLoading] = useState(true)
  const [messageText, setMessageText] = useState("")
  const [isSending, setIsSending] = useState(false)
  const [isTyping, setIsTyping] = useState(false)
  const [showEmojiPicker, setShowEmojiPicker] = useState(false)
  const [showGifPicker, setShowGifPicker] = useState(false)
  const [selectedMedia, setSelectedMedia] = useState<{ type: "image" | "video" | "audio" | "gif"; url: string }[]>([])
  const [replyingTo, setReplyingTo] = useState<string | null>(null)
  const [editingMessage, setEditingMessage] = useState<string | null>(null)
  const [showMediaPicker, setShowMediaPicker] = useState(false)
  const [isRecording, setIsRecording] = useState(false)
  const [recordingTime, setRecordingTime] = useState(0)
  const [recordingInterval, setRecordingInterval] = useState<NodeJS.Timeout | null>(null)

  const scrollAreaRef = useRef<HTMLDivElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  const router = useRouter()

  useEffect(() => {
    if (conversation) {
      const fetchMessages = async () => {
        setLoading(true)
        try {
          const data = await getMessages(conversation.id)
          // Add status to messages
          const enhancedData = data.map((msg: any) => ({
            ...msg,
            status: msg.senderId === "user-1" ? (msg.isRead ? "seen" : "delivered") : undefined,
            reactions: msg.reactions || [],
          }))
          setMessages(enhancedData)
        } catch (error) {
          console.error("Error fetching messages:", error)
        } finally {
          setLoading(false)
        }
      }

      fetchMessages()
    }
  }, [conversation])

  useEffect(() => {
    // Scroll to bottom when messages change
    if (scrollAreaRef.current) {
      scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight
    }
  }, [messages])

  // Simulate typing indicator from the other user
  useEffect(() => {
    if (conversation && messages.length > 0) {
      const randomTimeout = Math.floor(Math.random() * 10000) + 5000 // Random time between 5-15 seconds
      const typingTimeout = setTimeout(() => {
        setIsTyping(true)

        // Stop typing after a few seconds
        setTimeout(() => {
          setIsTyping(false)

          // Simulate receiving a new message
          const newMessage = {
            id: `message-${Date.now()}`,
            content: "Thanks for your message! How can I help you today?",
            timestamp: new Date().toISOString(),
            senderId: conversation.participant.id,
            isRead: false,
            status: undefined,
          }

          setMessages((prev) => [...prev, newMessage])
        }, 3000)
      }, randomTimeout)

      return () => clearTimeout(typingTimeout)
    }
  }, [conversation, messages.length])

  const handleSendMessage = () => {
    if ((!messageText.trim() && selectedMedia.length === 0) || !conversation || isSending) return

    setIsSending(true)

    // If editing a message
    if (editingMessage) {
      setMessages((prev) =>
        prev.map((msg) => (msg.id === editingMessage ? { ...msg, content: messageText, isEdited: true } : msg)),
      )
      setEditingMessage(null)
      setMessageText("")
      setIsSending(false)
      return
    }

    // Create new message
    const newMessage: Message = {
      id: `message-${Date.now()}`,
      content: messageText,
      timestamp: new Date().toISOString(),
      senderId: "user-1", // Current user ID
      isRead: false,
      status: "sent",
      media: selectedMedia.length > 0 ? selectedMedia : undefined,
      replyTo: replyingTo,
    }

    // Add self-destruct if needed
    if (selfDestructTime) {
      const expiryDate = new Date()
      expiryDate.setHours(expiryDate.getHours() + Number.parseInt(selfDestructTime))
      newMessage.expiresAt = expiryDate.toISOString()
    }

    setMessages((prev) => [...prev, newMessage])
    setMessageText("")
    setSelectedMedia([])
    setReplyingTo(null)
    setSelfDestructTime(null)
    setIsSending(false)

    // Simulate message status updates
    setTimeout(() => {
      setMessages((prev) => prev.map((msg) => (msg.id === newMessage.id ? { ...msg, status: "delivered" } : msg)))

      // Simulate seen after 2 more seconds
      setTimeout(() => {
        setMessages((prev) => prev.map((msg) => (msg.id === newMessage.id ? { ...msg, status: "seen" } : msg)))
      }, 2000)
    }, 1000)
  }

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  const handleTyping = () => {
    // Simulate typing indicator for the current user
    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current)
    }

    // Set a timeout to clear the typing indicator
    typingTimeoutRef.current = setTimeout(() => {
      // In a real app, we would send a "stopped typing" event to the server
    }, 1000)

    // In a real app, we would send a "typing" event to the server
  }

  const handleEmojiSelect = (emoji: string) => {
    setMessageText((prev) => prev + emoji)
    setShowEmojiPicker(false)
  }

  const handleGifSelect = (gifUrl: string) => {
    setSelectedMedia((prev) => [...prev, { type: "gif", url: gifUrl }])
    setShowGifPicker(false)
  }

  const handleFileSelect = () => {
    fileInputRef.current?.click()
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files || files.length === 0) return

    Array.from(files).forEach((file) => {
      const reader = new FileReader()
      reader.onload = (event) => {
        if (event.target?.result) {
          const fileUrl = event.target.result as string
          const fileType = file.type.startsWith("image/")
            ? "image"
            : file.type.startsWith("video/")
              ? "video"
              : file.type.startsWith("audio/")
                ? "audio"
                : "image"

          setSelectedMedia((prev) => [...prev, { type: fileType, url: fileUrl }])
        }
      }
      reader.readAsDataURL(file)
    })

    // Reset the input
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const removeMedia = (index: number) => {
    setSelectedMedia((prev) => prev.filter((_, i) => i !== index))
  }

  const handleReplyToMessage = (messageId: string) => {
    setReplyingTo(messageId)
    // Focus the input
    document.getElementById("message-input")?.focus()
  }

  const handleEditMessage = (messageId: string) => {
    const message = messages.find((msg) => msg.id === messageId)
    if (message && message.senderId === "user-1") {
      setEditingMessage(messageId)
      setMessageText(message.content)
      // Focus the input
      document.getElementById("message-input")?.focus()
    }
  }

  const handleDeleteMessage = (messageId: string) => {
    setMessages((prev) => prev.filter((msg) => msg.id !== messageId))
  }

  const handleForwardMessage = (messageId: string) => {
    // In a real app, this would open a dialog to select recipients
    alert(`Message would be forwarded to other users`)
  }

  const handleReaction = (messageId: string, emoji: string) => {
    setMessages((prev) =>
      prev.map((msg) => {
        if (msg.id === messageId) {
          const existingReactionIndex = msg.reactions?.findIndex((r) => r.userId === "user-1" && r.emoji === emoji)

          let updatedReactions = msg.reactions || []

          if (existingReactionIndex !== undefined && existingReactionIndex >= 0) {
            // Remove the reaction if it already exists
            updatedReactions = updatedReactions.filter((_, i) => i !== existingReactionIndex)
          } else {
            // Add the reaction
            updatedReactions = [...updatedReactions, { emoji, userId: "user-1" }]
          }

          return { ...msg, reactions: updatedReactions }
        }
        return msg
      }),
    )
  }

  const [selfDestructTime, setSelfDestructTime] = useState<string | null>(null)

  const handleStartRecording = () => {
    setIsRecording(true)
    setRecordingTime(0)

    // Start timer
    const interval = setInterval(() => {
      setRecordingTime((prev) => prev + 1)
    }, 1000)

    setRecordingInterval(interval)

    // In a real app, we would start recording audio here
  }

  const handleStopRecording = () => {
    setIsRecording(false)

    if (recordingInterval) {
      clearInterval(recordingInterval)
    }

    // In a real app, we would stop recording and add the audio file to selectedMedia
    setSelectedMedia((prev) => [
      ...prev,
      {
        type: "audio",
        url: "/placeholder.svg?height=50&width=300",
      },
    ])
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs < 10 ? "0" : ""}${secs}`
  }

  const getReplyingToMessage = () => {
    if (!replyingTo) return null
    return messages.find((msg) => msg.id === replyingTo)
  }

  const replyMessage = getReplyingToMessage()

  const getMessageStatusIcon = (status?: "sent" | "delivered" | "seen") => {
    switch (status) {
      case "sent":
        return <Check className="h-3 w-3 text-muted-foreground" />
      case "delivered":
        return <CheckCheck className="h-3 w-3 text-muted-foreground" />
      case "seen":
        return <CheckCheck className="h-3 w-3 text-blue-500" />
      default:
        return null
    }
  }

  if (!conversation) {
    return (
      <div className={cn("flex h-full flex-col items-center justify-center", className)}>
        <div className="max-w-md text-center">
          <h3 className="mb-2 text-xl font-semibold">Select a conversation</h3>
          <p className="text-muted-foreground">Choose a conversation from the list or start a new one.</p>
        </div>
      </div>
    )
  }

  return (
    <div className={cn("flex h-full flex-col", className)}>
      <div className="flex items-center justify-between border-b px-4 py-2">
        <div className="flex items-center">
          <Button
            variant="ghost"
            size="icon"
            className="mr-2 md:hidden rounded-full"
            onClick={() => router.push("/messages")}
          >
            <ArrowLeft className="h-5 w-5" />
            <span className="sr-only">Back to messages</span>
          </Button>
          <div className="relative">
            <Avatar className="h-10 w-10">
              <AvatarImage src={conversation.participant.avatar} alt={conversation.participant.name} />
              <AvatarFallback>{conversation.participant.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <span
              className={cn(
                "absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-background",
                conversation.participant.isOnline ? "bg-green-500" : "bg-gray-400",
              )}
            />
          </div>
          <div className="ml-4">
            <p className="font-medium">{conversation.participant.name}</p>
            <p className="text-xs text-muted-foreground">{conversation.participant.isOnline ? "Online" : "Offline"}</p>
          </div>
        </div>
        <div className="flex items-center space-x-1">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon" className="rounded-full">
                  <VideoIcon className="h-5 w-5" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Video call</TooltipContent>
            </Tooltip>
          </TooltipProvider>

          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon" className="rounded-full">
                  <Mic className="h-5 w-5" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Voice call</TooltipContent>
            </Tooltip>
          </TooltipProvider>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="rounded-full">
                <MoreHorizontal className="h-5 w-5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>
                <FileText className="mr-2 h-4 w-4" />
                View shared files
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Search className="mr-2 h-4 w-4" />
                Search in conversation
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem>
                <Ban className="mr-2 h-4 w-4 text-red-500" />
                <span className="text-red-500">Block user</span>
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Flag className="mr-2 h-4 w-4 text-red-500" />
                <span className="text-red-500">Report user</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      <ScrollArea className="flex-1 p-4 overflow-y-auto" ref={scrollAreaRef}>
        {loading ? (
          <div className="flex justify-center p-4">
            <Icons.spinner className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : messages.length === 0 ? (
          <div className="flex h-full items-center justify-center">
            <p className="text-center text-muted-foreground">No messages yet</p>
          </div>
        ) : (
          <div className="space-y-4">
            {messages.map((message) => {
              const isCurrentUser = message.senderId === "user-1"
              const replyToMessage = message.replyTo ? messages.find((m) => m.id === message.replyTo) : null

              // Check if message should be deleted (self-destructing)
              if (message.expiresAt && new Date(message.expiresAt) < new Date()) {
                return null
              }

              return (
                <div key={message.id} className={cn("flex", isCurrentUser ? "justify-end" : "justify-start")}>
                  <div className="flex max-w-[85%] sm:max-w-[70%] flex-col items-end space-y-1">
                    <div className="flex items-end space-x-2">
                      {!isCurrentUser && (
                        <Avatar className="h-8 w-8">
                          <AvatarImage src={conversation.participant.avatar} alt={conversation.participant.name} />
                          <AvatarFallback>{conversation.participant.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                      )}

                      <div className="flex flex-col space-y-1">
                        {/* Reply reference */}
                        {replyToMessage && (
                          <div
                            className={cn(
                              "rounded-lg px-3 py-2 text-sm",
                              isCurrentUser
                                ? "bg-primary/20 text-primary-foreground/80"
                                : "bg-muted/50 text-foreground/80",
                            )}
                          >
                            <div className="flex items-center">
                              <Reply className="mr-1 h-3 w-3" />
                              <span className="text-xs font-medium">
                                {replyToMessage.senderId === "user-1" ? "You" : conversation.participant.name}
                              </span>
                            </div>
                            <p className="line-clamp-1 text-xs opacity-80">{replyToMessage.content}</p>
                          </div>
                        )}

                        {/* Message content */}
                        <Card
                          className={cn(
                            "px-3 py-2 space-y-2 break-words",
                            isCurrentUser ? "bg-primary text-primary-foreground" : "bg-muted",
                          )}
                        >
                          {/* Media content */}
                          {message.media && message.media.length > 0 && (
                            <div className="space-y-2">
                              {message.media.map((media, index) => (
                                <div key={index} className="rounded overflow-hidden">
                                  {media.type === "image" && (
                                    <img
                                      src={media.url || "/placeholder.svg"}
                                      alt="Shared image"
                                      className="max-h-[200px] w-auto object-contain"
                                    />
                                  )}
                                  {media.type === "video" && (
                                    <video src={media.url} controls className="max-h-[200px] w-auto max-w-full" />
                                  )}
                                  {media.type === "audio" && <audio src={media.url} controls className="w-full" />}
                                  {media.type === "gif" && (
                                    <img
                                      src={media.url || "/placeholder.svg"}
                                      alt="GIF"
                                      className="max-h-[200px] w-auto object-contain"
                                    />
                                  )}
                                </div>
                              ))}
                            </div>
                          )}

                          {/* Text content */}
                          {message.content && <p className="text-sm break-words">{message.content}</p>}

                          {/* Self-destruct indicator */}
                          {message.expiresAt && (
                            <div className="flex items-center text-xs opacity-70">
                              <Timer className="mr-1 h-3 w-3" />
                              <span>Expires {format(new Date(message.expiresAt), "MMM d, h:mm a")}</span>
                            </div>
                          )}

                          {/* Message info */}
                          <div className="flex items-center justify-between mt-1">
                            <span className="text-xs opacity-70">
                              {format(new Date(message.timestamp), "h:mm a")}
                              {message.isEdited && <span className="ml-1">(edited)</span>}
                            </span>
                            {isCurrentUser && <span className="ml-1">{getMessageStatusIcon(message.status)}</span>}
                          </div>
                        </Card>

                        {/* Reactions */}
                        {message.reactions && message.reactions.length > 0 && (
                          <div className="flex items-center space-x-1 bg-background rounded-full px-2 py-0.5 border shadow-sm">
                            {message.reactions.map((reaction, index) => (
                              <span key={index} className="text-sm">
                                {reaction.emoji}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Message actions */}
                    <div className={cn("flex items-center space-x-1", isCurrentUser ? "justify-end" : "justify-start")}>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button variant="ghost" size="sm" className="h-6 w-6 p-0 rounded-full">
                            <Smile className="h-3 w-3" />
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-1 flex space-x-1">
                          {["👍", "❤️", "😂", "😮", "😢", "👏"].map((emoji) => (
                            <Button
                              key={emoji}
                              variant="ghost"
                              size="sm"
                              className="h-8 w-8 p-0 rounded-full"
                              onClick={() => handleReaction(message.id, emoji)}
                            >
                              {emoji}
                            </Button>
                          ))}
                        </PopoverContent>
                      </Popover>

                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-6 w-6 p-0 rounded-full"
                        onClick={() => handleReplyToMessage(message.id)}
                      >
                        <Reply className="h-3 w-3" />
                      </Button>

                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm" className="h-6 w-6 p-0 rounded-full">
                            <MoreHorizontal className="h-3 w-3" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align={isCurrentUser ? "end" : "start"} side="top">
                          <DropdownMenuItem onClick={() => handleReplyToMessage(message.id)}>
                            <Reply className="mr-2 h-4 w-4" />
                            Reply
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleForwardMessage(message.id)}>
                            <Forward className="mr-2 h-4 w-4" />
                            Forward
                          </DropdownMenuItem>
                          {isCurrentUser && (
                            <>
                              <DropdownMenuItem onClick={() => handleEditMessage(message.id)}>
                                <Edit className="mr-2 h-4 w-4" />
                                Edit
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem
                                onClick={() => handleDeleteMessage(message.id)}
                                className="text-red-500 focus:text-red-500"
                              >
                                <Trash className="mr-2 h-4 w-4" />
                                Delete
                              </DropdownMenuItem>
                            </>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                </div>
              )
            })}

            {/* Typing indicator */}
            {isTyping && (
              <div className="flex items-start space-x-2">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={conversation.participant.avatar} alt={conversation.participant.name} />
                  <AvatarFallback>{conversation.participant.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div className="bg-muted rounded-lg px-3 py-2">
                  <div className="flex space-x-1">
                    <div
                      className="h-2 w-2 rounded-full bg-muted-foreground animate-bounce"
                      style={{ animationDelay: "0ms" }}
                    ></div>
                    <div
                      className="h-2 w-2 rounded-full bg-muted-foreground animate-bounce"
                      style={{ animationDelay: "200ms" }}
                    ></div>
                    <div
                      className="h-2 w-2 rounded-full bg-muted-foreground animate-bounce"
                      style={{ animationDelay: "400ms" }}
                    ></div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </ScrollArea>

      {/* Reply indicator */}
      {replyMessage && (
        <div className="border-t px-4 py-2 flex items-center justify-between bg-muted/30">
          <div className="flex items-center">
            <Reply className="mr-2 h-4 w-4 text-muted-foreground" />
            <div>
              <p className="text-xs font-medium">
                Replying to {replyMessage.senderId === "user-1" ? "yourself" : conversation.participant.name}
              </p>
              <p className="text-xs text-muted-foreground line-clamp-1">{replyMessage.content}</p>
            </div>
          </div>
          <Button variant="ghost" size="sm" className="h-6 w-6 p-0 rounded-full" onClick={() => setReplyingTo(null)}>
            <X className="h-4 w-4" />
          </Button>
        </div>
      )}

      {/* Edit indicator */}
      {editingMessage && (
        <div className="border-t px-4 py-2 flex items-center justify-between bg-muted/30">
          <div className="flex items-center">
            <Edit className="mr-2 h-4 w-4 text-muted-foreground" />
            <p className="text-xs font-medium">Editing message</p>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="h-6 w-6 p-0 rounded-full"
            onClick={() => {
              setEditingMessage(null)
              setMessageText("")
            }}
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      )}

      {/* Selected media preview */}
      {selectedMedia.length > 0 && (
        <div className="border-t px-4 py-2 flex items-center space-x-2 overflow-x-auto">
          {selectedMedia.map((media, index) => (
            <div key={index} className="relative rounded-md overflow-hidden border h-16 w-16 flex-shrink-0">
              {media.type === "image" && (
                <img
                  src={media.url || "/placeholder.svg"}
                  alt="Selected media"
                  className="h-full w-full object-cover"
                />
              )}
              {media.type === "video" && (
                <div className="h-full w-full bg-muted flex items-center justify-center">
                  <Play className="h-6 w-6 text-muted-foreground" />
                </div>
              )}
              {media.type === "audio" && (
                <div className="h-full w-full bg-muted flex items-center justify-center">
                  <Volume2 className="h-6 w-6 text-muted-foreground" />
                </div>
              )}
              {media.type === "gif" && (
                <div className="h-full w-full bg-muted flex items-center justify-center">
                  <Gif className="h-6 w-6 text-muted-foreground" />
                </div>
              )}
              <Button
                variant="secondary"
                size="icon"
                className="absolute right-0.5 top-0.5 h-5 w-5 p-0 rounded-full bg-background/80"
                onClick={() => removeMedia(index)}
              >
                <X className="h-3 w-3" />
              </Button>
            </div>
          ))}
        </div>
      )}

      <div className="border-t p-4">
        <div className="flex items-center space-x-2">
          <div className="flex items-center space-x-1">
            <input
              type="file"
              ref={fileInputRef}
              className="hidden"
              accept="image/*,video/*,audio/*"
              onChange={handleFileChange}
              multiple
            />

            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="rounded-full" onClick={handleFileSelect}>
                    <Paperclip className="h-5 w-5" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Attach file</TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="rounded-full"
                    onClick={() => setShowGifPicker(!showGifPicker)}
                  >
                    <Gif className="h-5 w-5" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Add GIF</TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="rounded-full"
                    onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                  >
                    <Smile className="h-5 w-5" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Add emoji</TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="rounded-full">
                  <Timer className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start">
                <DropdownMenuItem onClick={() => setSelfDestructTime(null)}>
                  <Clock className="mr-2 h-4 w-4" />
                  Don't auto-delete
                  {!selfDestructTime && <Check className="ml-auto h-4 w-4" />}
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => setSelfDestructTime("1")}>
                  <Clock className="mr-2 h-4 w-4" />
                  Delete after 1 hour
                  {selfDestructTime === "1" && <Check className="ml-auto h-4 w-4" />}
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setSelfDestructTime("24")}>
                  <Clock className="mr-2 h-4 w-4" />
                  Delete after 24 hours
                  {selfDestructTime === "24" && <Check className="ml-auto h-4 w-4" />}
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setSelfDestructTime("72")}>
                  <Clock className="mr-2 h-4 w-4" />
                  Delete after 3 days
                  {selfDestructTime === "72" && <Check className="ml-auto h-4 w-4" />}
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          <div className="relative flex-1">
            {isRecording ? (
              <div className="flex items-center space-x-2 border rounded-md px-3 py-2 bg-red-50 dark:bg-red-900/20">
                <div className="h-2 w-2 rounded-full bg-red-500 animate-pulse" />
                <span className="text-sm">Recording... {formatTime(recordingTime)}</span>
                <Button
                  variant="ghost"
                  size="sm"
                  className="ml-auto h-8 w-8 p-0 rounded-full"
                  onClick={handleStopRecording}
                >
                  <Check className="h-4 w-4" />
                </Button>
              </div>
            ) : (
              <Input
                id="message-input"
                placeholder={editingMessage ? "Edit your message..." : "Type a message..."}
                value={messageText}
                onChange={(e) => {
                  setMessageText(e.target.value)
                  handleTyping()
                }}
                onKeyDown={handleKeyDown}
                className="pr-10"
              />
            )}
          </div>

          {messageText.trim() || selectedMedia.length > 0 ? (
            <Button size="icon" className="rounded-full flex-shrink-0" disabled={isSending} onClick={handleSendMessage}>
              {isSending ? <Icons.spinner className="h-5 w-5 animate-spin" /> : <Send className="h-5 w-5" />}
            </Button>
          ) : (
            <Button
              variant="ghost"
              size="icon"
              className={cn("rounded-full flex-shrink-0", isRecording && "text-red-500")}
              onMouseDown={handleStartRecording}
              onMouseUp={handleStopRecording}
              onMouseLeave={isRecording ? handleStopRecording : undefined}
            >
              <Mic className="h-5 w-5" />
            </Button>
          )}
        </div>

        {/* Self-destruct indicator */}
        {selfDestructTime && (
          <div className="mt-2 flex items-center text-xs text-muted-foreground">
            <Timer className="mr-1 h-3 w-3" />
            <span>
              Message will self-destruct after{" "}
              {selfDestructTime === "1" ? "1 hour" : selfDestructTime === "24" ? "24 hours" : "3 days"}
            </span>
          </div>
        )}
      </div>

      {/* Emoji Picker */}
      {showEmojiPicker && (
        <div className="absolute bottom-20 right-4 z-10 max-w-[90vw] sm:max-w-none">
          <EmojiPicker onEmojiSelect={handleEmojiSelect} />
        </div>
      )}

      {/* GIF Picker */}
      {showGifPicker && (
        <div className="absolute bottom-20 right-4 z-10 max-w-[90vw] sm:max-w-none">
          <GifPicker onGifSelect={handleGifSelect} />
        </div>
      )}
    </div>
  )
}


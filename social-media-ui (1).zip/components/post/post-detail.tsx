import Link from "next/link"
import Image from "next/image"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Heart, MessageCircle, Repeat, Share } from "lucide-react"

interface PostDetailProps {
  post: any
}

export function PostDetail({ post }: PostDetailProps) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-start space-y-0">
        <Link href={`/profile/${post.author.username}`} className="flex items-center space-x-4">
          <Avatar className="h-12 w-12">
            <AvatarImage src={post.author.avatar} alt={post.author.name} />
            <AvatarFallback>{post.author.name.charAt(0)}</AvatarFallback>
          </Avatar>
          <div className="space-y-1">
            <div className="flex flex-col">
              <span className="font-semibold">{post.author.name}</span>
              <span className="text-sm text-muted-foreground">@{post.author.username}</span>
            </div>
          </div>
        </Link>
      </CardHeader>
      <CardContent>
        <p className="whitespace-pre-line text-lg">{post.content}</p>
        {post.image && (
          <div className="mt-4 overflow-hidden rounded-lg">
            <Image
              src={post.image || "/placeholder.svg"}
              alt="Post image"
              width={800}
              height={500}
              className="h-auto w-full object-cover"
            />
          </div>
        )}
        <div className="mt-4 text-sm text-muted-foreground">
          {new Date(post.createdAt).toLocaleString()} · {post.views} views
        </div>
      </CardContent>
      <CardFooter className="flex justify-between border-t py-4">
        <Button variant="ghost" size="sm" className="rounded-full text-muted-foreground">
          <MessageCircle className="mr-1 h-5 w-5" />
          {post.comments}
        </Button>
        <Button variant="ghost" size="sm" className="rounded-full text-muted-foreground">
          <Repeat className="mr-1 h-5 w-5" />
          {post.reposts}
        </Button>
        <Button variant="ghost" size="sm" className="rounded-full text-muted-foreground">
          <Heart className="mr-1 h-5 w-5" />
          {post.likes}
        </Button>
        <Button variant="ghost" size="sm" className="rounded-full text-muted-foreground">
          <Share className="mr-1 h-5 w-5" />
          Share
        </Button>
      </CardFooter>
    </Card>
  )
}


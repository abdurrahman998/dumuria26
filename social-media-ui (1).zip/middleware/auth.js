import { ApiError } from "../utils/ApiError.js"
import { verifyToken } from "../utils/jwt.js"
import User from "../models/User.js"

export const authMiddleware = async (req, res, next) => {
  try {
    // Get token from header
    const authHeader = req.headers.authorization

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      throw new ApiError(401, "Unauthorized - No token provided")
    }

    const token = authHeader.split(" ")[1]

    // Verify token
    const decoded = verifyToken(token)

    // Find user by id
    const user = await User.findById(decoded.id)

    if (!user) {
      throw new ApiError(401, "Unauthorized - User not found")
    }

    if (!user.isActive) {
      throw new ApiError(403, "Account is deactivated")
    }

    // Attach user to request
    req.user = user
    next()
  } catch (error) {
    next(new ApiError(401, "Unauthorized - Invalid token"))
  }
}


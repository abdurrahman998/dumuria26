import express from "express"
import { asyncHandler } from "../utils/asyncHandler.js"
import { verifyToken, moderatorAndAbove } from "../middleware/auth.js"
import { upload } from "../utils/fileUpload.js"
import {
  createPost,
  getPostById,
  updatePost,
  deletePost,
  likePost,
  unlikePost,
  getFeedPosts,
  getUserPosts,
  savePost,
  unsavePost,
  getSavedPosts,
  reportPost,
  getReportedPosts,
  resolveReport,
  searchPosts,
  getTrendingPosts,
  voteOnPoll,
} from "../controllers/postController.js"

const router = express.Router()

// Public routes
router.get("/:id", asyncHandler(getPostById))
router.get("/user/:userId", asyncHandler(getUserPosts))
router.get("/search", asyncHandler(searchPosts))
router.get("/trending", asyncHandler(getTrendingPosts))

// Protected routes
router.use(verifyToken)
router.post("/", upload.array("media", 5), asyncHandler(createPost)) // Allow up to 5 media files
router.put("/:id", asyncHandler(updatePost))
router.delete("/:id", asyncHandler(deletePost))
router.post("/:id/like", asyncHandler(likePost))
router.post("/:id/unlike", asyncHandler(unlikePost))
router.get("/feed", asyncHandler(getFeedPosts))
router.post("/:id/save", asyncHandler(savePost))
router.post("/:id/unsave", asyncHandler(unsavePost))
router.get("/saved", asyncHandler(getSavedPosts))
router.post("/:id/report", asyncHandler(reportPost))
router.post("/:id/poll/:optionId/vote", asyncHandler(voteOnPoll))

// Moderator routes
router.use(moderatorAndAbove)
router.get("/reported", asyncHandler(getReportedPosts))
router.post("/reported/:id/resolve", asyncHandler(resolveReport))

export default router


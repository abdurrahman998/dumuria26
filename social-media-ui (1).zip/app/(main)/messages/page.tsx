import type { Metadata } from "next"
import { MessageList } from "@/components/messages/message-list"

export const metadata: Metadata = {
  title: "Messages | SocialSphere",
  description: "Your conversations on SocialSphere",
}

// Update the layout to be responsive for mobile
export default function MessagesPage() {
  return (
    <div className="flex h-[calc(100vh-3.5rem-1px)] flex-col md:flex-row">
      <MessageList className="w-full border-r md:w-80" />
      <div className="hidden flex-1 items-center justify-center md:flex">
        <div className="max-w-md text-center">
          <h3 className="mb-2 text-xl font-semibold">Select a conversation</h3>
          <p className="text-muted-foreground">Choose a conversation from the list or start a new one.</p>
        </div>
      </div>
    </div>
  )
}


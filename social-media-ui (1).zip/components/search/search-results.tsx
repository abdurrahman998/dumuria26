"use client"

import { useState } from "react"
import Link from "next/link"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import { PostCard } from "@/components/post/post-card"
import { Hash, Users, ChevronRight, Search } from "lucide-react"

interface SearchResultsProps {
  results: {
    users?: any[]
    posts?: any[]
    hashtags?: any[]
    groups?: any[]
  }
  isLoading: boolean
  query: string
  showAllCategories?: boolean
}

export function SearchResults({ results, isLoading, query, showAllCategories = false }: SearchResultsProps) {
  const [followingStates, setFollowingStates] = useState<Record<string, boolean>>({})

  const handleFollow = (userId: string) => {
    setFollowingStates((prev) => ({
      ...prev,
      [userId]: !prev[userId],
    }))
  }

  if (isLoading) {
    return (
      <div className="space-y-4">
        {Array.from({ length: 3 }).map((_, i) => (
          <Card key={i}>
            <CardHeader className="pb-2">
              <Skeleton className="h-5 w-32" />
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {Array.from({ length: 2 }).map((_, j) => (
                  <div key={j} className="flex items-center space-x-4">
                    <Skeleton className="h-12 w-12 rounded-full" />
                    <div className="space-y-2">
                      <Skeleton className="h-4 w-[200px]" />
                      <Skeleton className="h-4 w-[150px]" />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    )
  }

  const hasUsers = results.users && results.users.length > 0
  const hasPosts = results.posts && results.posts.length > 0
  const hasHashtags = results.hashtags && results.hashtags.length > 0
  const hasGroups = results.groups && results.groups.length > 0
  const hasResults = hasUsers || hasPosts || hasHashtags || hasGroups

  if (!hasResults) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center justify-center py-8">
          <div className="rounded-full bg-muted p-3">
            <Search className="h-6 w-6 text-muted-foreground" />
          </div>
          <h3 className="mt-4 text-lg font-medium">No results found</h3>
          <p className="mt-2 text-center text-muted-foreground">
            We couldn't find anything for "{query}". Try searching for something else.
          </p>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {showAllCategories ? (
        <>
          {hasUsers && (
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <div>
                  <CardTitle className="text-lg">People</CardTitle>
                  <CardDescription>People matching "{query}"</CardDescription>
                </div>
                {results.users && results.users.length > 3 && (
                  <Button variant="ghost" size="sm" asChild>
                    <Link href={`/search?q=${encodeURIComponent(query)}&category=users`}>
                      See all
                      <ChevronRight className="ml-1 h-4 w-4" />
                    </Link>
                  </Button>
                )}
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {results.users?.slice(0, 3).map((user) => (
                    <div key={user.id} className="flex items-center justify-between">
                      <Link href={`/profile/${user.username}`} className="flex items-center space-x-3">
                        <Avatar>
                          <AvatarImage src={user.avatar} alt={user.name} />
                          <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-medium">{user.name}</div>
                          <div className="text-sm text-muted-foreground">@{user.username}</div>
                        </div>
                      </Link>
                      <Button
                        variant={followingStates[user.id] ? "outline" : "default"}
                        size="sm"
                        onClick={() => handleFollow(user.id)}
                      >
                        {followingStates[user.id] ? "Following" : "Follow"}
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {hasPosts && (
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <div>
                  <CardTitle className="text-lg">Posts</CardTitle>
                  <CardDescription>Posts matching "{query}"</CardDescription>
                </div>
                {results.posts && results.posts.length > 2 && (
                  <Button variant="ghost" size="sm" asChild>
                    <Link href={`/search?q=${encodeURIComponent(query)}&category=posts`}>
                      See all
                      <ChevronRight className="ml-1 h-4 w-4" />
                    </Link>
                  </Button>
                )}
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {results.posts?.slice(0, 2).map((post) => (
                    <PostCard key={post.id} post={post} />
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {hasHashtags && (
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <div>
                  <CardTitle className="text-lg">Hashtags</CardTitle>
                  <CardDescription>Hashtags matching "{query}"</CardDescription>
                </div>
                {results.hashtags && results.hashtags.length > 5 && (
                  <Button variant="ghost" size="sm" asChild>
                    <Link href={`/search?q=${encodeURIComponent(query)}&category=hashtags`}>
                      See all
                      <ChevronRight className="ml-1 h-4 w-4" />
                    </Link>
                  </Button>
                )}
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {results.hashtags?.slice(0, 5).map((hashtag) => (
                    <Link
                      key={hashtag.id}
                      href={`/search?q=${encodeURIComponent(hashtag.name)}&category=hashtags`}
                      className="inline-flex items-center rounded-full bg-muted px-3 py-1 text-sm hover:bg-muted/80"
                    >
                      <Hash className="mr-1 h-3 w-3" />
                      {hashtag.name}
                    </Link>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {hasGroups && (
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <div>
                  <CardTitle className="text-lg">Groups</CardTitle>
                  <CardDescription>Groups matching "{query}"</CardDescription>
                </div>
                {results.groups && results.groups.length > 3 && (
                  <Button variant="ghost" size="sm" asChild>
                    <Link href={`/search?q=${encodeURIComponent(query)}&category=groups`}>
                      See all
                      <ChevronRight className="ml-1 h-4 w-4" />
                    </Link>
                  </Button>
                )}
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {results.groups?.slice(0, 3).map((group) => (
                    <div key={group.id} className="flex items-center justify-between">
                      <Link href={`/groups/${group.id}`} className="flex items-center space-x-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-muted">
                          <Users className="h-5 w-5" />
                        </div>
                        <div>
                          <div className="font-medium">{group.name}</div>
                          <div className="text-sm text-muted-foreground">{group.members} members</div>
                        </div>
                      </Link>
                      <Button variant="outline" size="sm">
                        Join
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </>
      ) : (
        <>
          {hasUsers && (
            <div className="space-y-4">
              {results.users?.map((user) => (
                <Card key={user.id}>
                  <CardContent className="flex items-center justify-between p-4">
                    <Link href={`/profile/${user.username}`} className="flex items-center space-x-3">
                      <Avatar>
                        <AvatarImage src={user.avatar} alt={user.name} />
                        <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="font-medium">{user.name}</div>
                        <div className="text-sm text-muted-foreground">@{user.username}</div>
                      </div>
                    </Link>
                    <Button
                      variant={followingStates[user.id] ? "outline" : "default"}
                      size="sm"
                      onClick={() => handleFollow(user.id)}
                    >
                      {followingStates[user.id] ? "Following" : "Follow"}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          {hasPosts && (
            <div className="space-y-4">
              {results.posts?.map((post) => (
                <PostCard key={post.id} post={post} />
              ))}
            </div>
          )}

          {hasHashtags && (
            <Card>
              <CardContent className="p-4">
                <div className="flex flex-wrap gap-2">
                  {results.hashtags?.map((hashtag) => (
                    <Link
                      key={hashtag.id}
                      href={`/search?q=${encodeURIComponent(hashtag.name)}&category=hashtags`}
                      className="inline-flex items-center rounded-full bg-muted px-3 py-1 text-sm hover:bg-muted/80"
                    >
                      <Hash className="mr-1 h-3 w-3" />
                      {hashtag.name}
                    </Link>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {hasGroups && (
            <div className="space-y-4">
              {results.groups?.map((group) => (
                <Card key={group.id}>
                  <CardContent className="flex items-center justify-between p-4">
                    <Link href={`/groups/${group.id}`} className="flex items-center space-x-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-muted">
                        <Users className="h-5 w-5" />
                      </div>
                      <div>
                        <div className="font-medium">{group.name}</div>
                        <div className="text-sm text-muted-foreground">{group.members} members</div>
                      </div>
                    </Link>
                    <Button variant="outline" size="sm">
                      Join
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  )
}


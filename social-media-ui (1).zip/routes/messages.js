import express from "express"
import { asyncHandler } from "../utils/asyncHandler.js"
import { verifyToken } from "../middleware/auth.js"
import {
  createConversation,
  getConversations,
  getConversationById,
  updateConversation,
  deleteConversation,
  sendMessage,
  getMessages,
  getMessageById,
  deleteMessage,
  markAsRead,
  reactToMessage,
  removeReaction,
  editMessage,
  pinConversation,
  unpinConversation,
  muteConversation,
  unmuteConversation,
  addParticipant,
  removeParticipant,
  leaveConversation,
} from "../controllers/messageController.js"

const router = express.Router()

// All routes require authentication
router.use(verifyToken)

// Conversation routes
router.post("/conversations", asyncHandler(createConversation))
router.get("/conversations", asyncHandler(getConversations))
router.get("/conversations/:id", asyncHandler(getConversationById))
router.put("/conversations/:id", asyncHandler(updateConversation))
router.delete("/conversations/:id", asyncHandler(deleteConversation))
router.post("/conversations/:id/pin", asyncHandler(pinConversation))
router.post("/conversations/:id/unpin", asyncHandler(unpinConversation))
router.post("/conversations/:id/mute", asyncHandler(muteConversation))
router.post("/conversations/:id/unmute", asyncHandler(unmuteConversation))
router.post("/conversations/:id/participants", asyncHandler(addParticipant))
router.delete("/conversations/:id/participants/:userId", asyncHandler(removeParticipant))
router.post("/conversations/:id/leave", asyncHandler(leaveConversation))

// Message routes
router.post("/conversations/:conversationId/messages", asyncHandler(sendMessage))
router.get("/conversations/:conversationId/messages", asyncHandler(getMessages))
router.get("/messages/:id", asyncHandler(getMessageById))
router.put("/messages/:id", asyncHandler(editMessage))
router.delete("/messages/:id", asyncHandler(deleteMessage))
router.post("/messages/:id/read", asyncHandler(markAsRead))
router.post("/messages/:id/reactions", asyncHandler(reactToMessage))
router.delete("/messages/:id/reactions/:emoji", asyncHandler(removeReaction))

export default router


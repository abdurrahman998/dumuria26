"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Icons } from "@/components/icons"

export function PrivacySettings() {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [settings, setSettings] = useState({
    privateAccount: false,
    showOnlineStatus: true,
    allowTagging: true,
    allowMentions: true,
    allowDirectMessages: true,
    showReadReceipts: true,
  })

  const handleToggle = (name: string) => {
    setSettings((prev) => ({ ...prev, [name]: !prev[name as keyof typeof prev] }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false)
    }, 1000)
  }

  return (
    <form onSubmit={handleSubmit}>
      <Card>
        <CardHeader>
          <CardTitle>Privacy</CardTitle>
          <CardDescription>Manage your privacy settings.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="privateAccount">Private Account</Label>
              <p className="text-sm text-muted-foreground">Only approved followers can see your posts</p>
            </div>
            <Switch
              id="privateAccount"
              checked={settings.privateAccount}
              onCheckedChange={() => handleToggle("privateAccount")}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="showOnlineStatus">Show Online Status</Label>
              <p className="text-sm text-muted-foreground">Let others see when you're online</p>
            </div>
            <Switch
              id="showOnlineStatus"
              checked={settings.showOnlineStatus}
              onCheckedChange={() => handleToggle("showOnlineStatus")}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="allowTagging">Allow Tagging</Label>
              <p className="text-sm text-muted-foreground">Allow others to tag you in posts</p>
            </div>
            <Switch
              id="allowTagging"
              checked={settings.allowTagging}
              onCheckedChange={() => handleToggle("allowTagging")}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="allowMentions">Allow Mentions</Label>
              <p className="text-sm text-muted-foreground">Allow others to mention you in comments</p>
            </div>
            <Switch
              id="allowMentions"
              checked={settings.allowMentions}
              onCheckedChange={() => handleToggle("allowMentions")}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="allowDirectMessages">Allow Direct Messages</Label>
              <p className="text-sm text-muted-foreground">Allow others to send you direct messages</p>
            </div>
            <Switch
              id="allowDirectMessages"
              checked={settings.allowDirectMessages}
              onCheckedChange={() => handleToggle("allowDirectMessages")}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="showReadReceipts">Show Read Receipts</Label>
              <p className="text-sm text-muted-foreground">Let others know when you've read their messages</p>
            </div>
            <Switch
              id="showReadReceipts"
              checked={settings.showReadReceipts}
              onCheckedChange={() => handleToggle("showReadReceipts")}
            />
          </div>
        </CardContent>
        <CardFooter>
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting && <Icons.spinner className="mr-2 h-4 w-4 animate-spin" />}
            Save Changes
          </Button>
        </CardFooter>
      </Card>
    </form>
  )
}


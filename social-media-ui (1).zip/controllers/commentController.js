import Comment from "../models/Comment"
import Post from "../models/Post"
import { createNotification } from "./notificationController"

// Create a new comment
export const createComment = async (req, res) => {
  try {
    const { postId, content, parentId } = req.body
    const userId = req.user.id

    if (!content || content.trim() === "") {
      return res.status(400).json({ message: "Comment content cannot be empty" })
    }

    // Check if post exists
    const post = await Post.findById(postId)
    if (!post) {
      return res.status(404).json({ message: "Post not found" })
    }

    const newComment = new Comment({
      user: userId,
      post: postId,
      content,
      parent: parentId || null,
    })

    await newComment.save()

    // Update post with new comment
    post.comments.push(newComment._id)
    post.commentCount = post.commentCount + 1
    await post.save()

    // Populate user data for the response
    const populatedComment = await Comment.findById(newComment._id)
      .populate("user", "username name profilePicture")
      .exec()

    // Create notification for post owner (if not the same as commenter)
    if (post.user.toString() !== userId) {
      await createNotification({
        recipient: post.user,
        sender: userId,
        type: "comment",
        post: postId,
        comment: newComment._id,
      })
    }

    res.status(201).json(populatedComment)
  } catch (error) {
    console.error("Error creating comment:", error)
    res.status(500).json({ message: "Server error", error: error.message })
  }
}

// Get comments for a post
export const getPostComments = async (req, res) => {
  try {
    const { postId } = req.params
    const { page = 1, limit = 10 } = req.query

    const skip = (Number.parseInt(page) - 1) * Number.parseInt(limit)

    // Get top-level comments first (no parent)
    const comments = await Comment.find({
      post: postId,
      parent: null,
    })
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Number.parseInt(limit))
      .populate("user", "username name profilePicture")
      .populate({
        path: "replies",
        options: { sort: { createdAt: 1 }, limit: 3 },
        populate: { path: "user", select: "username name profilePicture" },
      })
      .exec()

    const totalComments = await Comment.countDocuments({ post: postId, parent: null })

    res.status(200).json({
      comments,
      totalPages: Math.ceil(totalComments / Number.parseInt(limit)),
      currentPage: Number.parseInt(page),
    })
  } catch (error) {
    console.error("Error fetching comments:", error)
    res.status(500).json({ message: "Server error", error: error.message })
  }
}

// Get replies for a comment
export const getCommentReplies = async (req, res) => {
  try {
    const { commentId } = req.params
    const { page = 1, limit = 10 } = req.query

    const skip = (Number.parseInt(page) - 1) * Number.parseInt(limit)

    const replies = await Comment.find({ parent: commentId })
      .sort({ createdAt: 1 })
      .skip(skip)
      .limit(Number.parseInt(limit))
      .populate("user", "username name profilePicture")
      .exec()

    const totalReplies = await Comment.countDocuments({ parent: commentId })

    res.status(200).json({
      replies,
      totalPages: Math.ceil(totalReplies / Number.parseInt(limit)),
      currentPage: Number.parseInt(page),
    })
  } catch (error) {
    console.error("Error fetching replies:", error)
    res.status(500).json({ message: "Server error", error: error.message })
  }
}

// Update a comment
export const updateComment = async (req, res) => {
  try {
    const { commentId } = req.params
    const { content } = req.body
    const userId = req.user.id

    if (!content || content.trim() === "") {
      return res.status(400).json({ message: "Comment content cannot be empty" })
    }

    const comment = await Comment.findById(commentId)

    if (!comment) {
      return res.status(404).json({ message: "Comment not found" })
    }

    // Check if user is the comment owner
    if (comment.user.toString() !== userId) {
      return res.status(403).json({ message: "Not authorized to update this comment" })
    }

    comment.content = content
    comment.isEdited = true
    await comment.save()

    const updatedComment = await Comment.findById(commentId).populate("user", "username name profilePicture").exec()

    res.status(200).json(updatedComment)
  } catch (error) {
    console.error("Error updating comment:", error)
    res.status(500).json({ message: "Server error", error: error.message })
  }
}

// Delete a comment
export const deleteComment = async (req, res) => {
  try {
    const { commentId } = req.params
    const userId = req.user.id

    const comment = await Comment.findById(commentId)

    if (!comment) {
      return res.status(404).json({ message: "Comment not found" })
    }

    // Check if user is the comment owner or post owner
    const post = await Post.findById(comment.post)

    if (comment.user.toString() !== userId && post.user.toString() !== userId) {
      return res.status(403).json({ message: "Not authorized to delete this comment" })
    }

    // If this is a parent comment, delete all replies
    if (!comment.parent) {
      await Comment.deleteMany({ parent: commentId })
    }

    // Delete the comment
    await Comment.findByIdAndDelete(commentId)

    // Update post comment count
    post.commentCount = Math.max(0, post.commentCount - 1)
    post.comments = post.comments.filter((id) => id.toString() !== commentId)
    await post.save()

    res.status(200).json({ message: "Comment deleted successfully" })
  } catch (error) {
    console.error("Error deleting comment:", error)
    res.status(500).json({ message: "Server error", error: error.message })
  }
}

// Like or unlike a comment
export const toggleCommentLike = async (req, res) => {
  try {
    const { commentId } = req.params
    const userId = req.user.id

    const comment = await Comment.findById(commentId)

    if (!comment) {
      return res.status(404).json({ message: "Comment not found" })
    }

    const isLiked = comment.likes.includes(userId)

    if (isLiked) {
      // Unlike the comment
      comment.likes = comment.likes.filter((id) => id.toString() !== userId)
    } else {
      // Like the comment
      comment.likes.push(userId)

      // Create notification if not the comment owner
      if (comment.user.toString() !== userId) {
        await createNotification({
          recipient: comment.user,
          sender: userId,
          type: "commentLike",
          comment: commentId,
        })
      }
    }

    await comment.save()

    res.status(200).json({
      likes: comment.likes.length,
      isLiked: !isLiked,
    })
  } catch (error) {
    console.error("Error toggling comment like:", error)
    res.status(500).json({ message: "Server error", error: error.message })
  }
}


"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useSearchParams, useRouter } from "next/navigation"
import Link from "next/link"
import { Loader2, ArrowLeft, Mail } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/hooks/use-toast"
import { useAuth } from "@/lib/auth"

export default function VerifyOTPPage() {
  const searchParams = useSearchParams()
  const router = useRouter()
  const { toast } = useToast()
  const { verifyOTP, resendOTP } = useAuth()

  const [email, setEmail] = useState<string>("")
  const [otp, setOtp] = useState<string>("")
  const [isLoading, setIsLoading] = useState<boolean>(false)
  const [resendDisabled, setResendDisabled] = useState<boolean>(false)
  const [countdown, setCountdown] = useState<number>(0)

  useEffect(() => {
    const emailParam = searchParams.get("email")
    if (emailParam) {
      setEmail(emailParam)
    } else {
      router.push("/register")
    }
  }, [searchParams, router])

  useEffect(() => {
    let timer: NodeJS.Timeout
    if (countdown > 0) {
      timer = setTimeout(() => setCountdown(countdown - 1), 1000)
    } else {
      setResendDisabled(false)
    }

    return () => {
      if (timer) clearTimeout(timer)
    }
  }, [countdown])

  const handleVerify = async () => {
    if (!otp) {
      toast({
        title: "Error",
        description: "Please enter the verification code",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)
    try {
      await verifyOTP(email, otp)
      toast({
        title: "Success",
        description: "Your account has been verified successfully!",
      })
      // The auth context will handle the redirect
    } catch (error: any) {
      toast({
        title: "Verification failed",
        description: error.message || "Invalid verification code. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleResend = async () => {
    setResendDisabled(true)
    setCountdown(60) // 60 seconds cooldown

    try {
      await resendOTP(email)
      toast({
        title: "Code sent",
        description: "A new verification code has been sent to your email.",
      })
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to resend verification code. Please try again later.",
        variant: "destructive",
      })
      setResendDisabled(false)
      setCountdown(0)
    }
  }

  // Handle OTP input - only allow numbers and limit to 6 digits
  const handleOtpChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/[^0-9]/g, "").slice(0, 6)
    setOtp(value)
  }

  return (
    <div className="container flex h-screen items-center justify-center">
      <Card className="w-full max-w-md mx-auto shadow-lg">
        <CardHeader>
          <CardTitle className="text-2xl font-bold">Verify your email</CardTitle>
          <CardDescription>
            We've sent a verification code to <span className="font-medium">{email}</span>
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex justify-center mb-4">
            <div className="rounded-full bg-primary/10 p-4">
              <Mail className="h-8 w-8 text-primary" />
            </div>
          </div>

          <div className="space-y-2">
            <label htmlFor="otp" className="text-sm font-medium">
              Enter verification code
            </label>
            <Input
              id="otp"
              placeholder="Enter 6-digit code"
              value={otp}
              onChange={handleOtpChange}
              className="text-center text-lg tracking-widest"
              maxLength={6}
            />
          </div>

          <Button onClick={handleVerify} className="w-full" disabled={isLoading || otp.length !== 6}>
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Verifying...
              </>
            ) : (
              "Verify"
            )}
          </Button>

          <div className="text-center text-sm">
            <p className="text-muted-foreground">
              Didn't receive a code?{" "}
              {resendDisabled ? (
                <span className="text-muted-foreground">Resend in {countdown}s</span>
              ) : (
                <button onClick={handleResend} className="text-primary hover:underline" disabled={resendDisabled}>
                  Resend code
                </button>
              )}
            </p>
          </div>
        </CardContent>
        <CardFooter className="flex justify-center border-t p-4">
          <Link href="/register" className="flex items-center text-sm text-muted-foreground hover:text-primary">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to registration
          </Link>
        </CardFooter>
      </Card>
    </div>
  )
}


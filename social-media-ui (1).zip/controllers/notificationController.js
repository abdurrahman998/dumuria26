import Notification from "../models/Notification"
import User from "../models/User"

// Create a notification (internal function)
export const createNotification = async ({
  recipient,
  sender,
  type,
  post = null,
  comment = null,
  conversation = null,
}) => {
  try {
    // Don't create notification if recipient has blocked sender
    const recipientUser = await User.findById(recipient)
    if (recipientUser.blockedUsers.includes(sender)) {
      return null
    }

    const notification = new Notification({
      recipient,
      sender,
      type,
      post,
      comment,
      conversation,
      read: false,
    })

    await notification.save()
    return notification
  } catch (error) {
    console.error("Error creating notification:", error)
    return null
  }
}

// Get user notifications
export const getUserNotifications = async (req, res) => {
  try {
    const userId = req.user.id
    const { page = 1, limit = 20 } = req.query

    const skip = (Number.parseInt(page) - 1) * Number.parseInt(limit)

    const notifications = await Notification.find({ recipient: userId })
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Number.parseInt(limit))
      .populate("sender", "username name profilePicture")
      .populate("post", "content images")
      .populate("comment", "content")
      .exec()

    const totalNotifications = await Notification.countDocuments({ recipient: userId })
    const unreadCount = await Notification.countDocuments({
      recipient: userId,
      read: false,
    })

    res.status(200).json({
      notifications,
      totalPages: Math.ceil(totalNotifications / Number.parseInt(limit)),
      currentPage: Number.parseInt(page),
      unreadCount,
    })
  } catch (error) {
    console.error("Error fetching notifications:", error)
    res.status(500).json({ message: "Server error", error: error.message })
  }
}

// Mark notification as read
export const markNotificationAsRead = async (req, res) => {
  try {
    const { notificationId } = req.params
    const userId = req.user.id

    const notification = await Notification.findById(notificationId)

    if (!notification) {
      return res.status(404).json({ message: "Notification not found" })
    }

    // Check if user is the recipient
    if (notification.recipient.toString() !== userId) {
      return res.status(403).json({ message: "Not authorized to update this notification" })
    }

    notification.read = true
    await notification.save()

    res.status(200).json({ message: "Notification marked as read" })
  } catch (error) {
    console.error("Error marking notification as read:", error)
    res.status(500).json({ message: "Server error", error: error.message })
  }
}

// Mark all notifications as read
export const markAllNotificationsAsRead = async (req, res) => {
  try {
    const userId = req.user.id

    await Notification.updateMany({ recipient: userId, read: false }, { read: true })

    res.status(200).json({ message: "All notifications marked as read" })
  } catch (error) {
    console.error("Error marking all notifications as read:", error)
    res.status(500).json({ message: "Server error", error: error.message })
  }
}

// Delete a notification
export const deleteNotification = async (req, res) => {
  try {
    const { notificationId } = req.params
    const userId = req.user.id

    const notification = await Notification.findById(notificationId)

    if (!notification) {
      return res.status(404).json({ message: "Notification not found" })
    }

    // Check if user is the recipient
    if (notification.recipient.toString() !== userId) {
      return res.status(403).json({ message: "Not authorized to delete this notification" })
    }

    await Notification.findByIdAndDelete(notificationId)

    res.status(200).json({ message: "Notification deleted successfully" })
  } catch (error) {
    console.error("Error deleting notification:", error)
    res.status(500).json({ message: "Server error", error: error.message })
  }
}

// Get unread notification count
export const getUnreadNotificationCount = async (req, res) => {
  try {
    const userId = req.user.id

    const unreadCount = await Notification.countDocuments({
      recipient: userId,
      read: false,
    })

    res.status(200).json({ unreadCount })
  } catch (error) {
    console.error("Error getting unread notification count:", error)
    res.status(500).json({ message: "Server error", error: error.message })
  }
}

// Update notification preferences
export const updateNotificationPreferences = async (req, res) => {
  try {
    const userId = req.user.id
    const { preferences } = req.body

    const user = await User.findById(userId)

    if (!user) {
      return res.status(404).json({ message: "User not found" })
    }

    // Update notification preferences
    user.notificationPreferences = {
      ...user.notificationPreferences,
      ...preferences,
    }

    await user.save()

    res.status(200).json({
      message: "Notification preferences updated",
      preferences: user.notificationPreferences,
    })
  } catch (error) {
    console.error("Error updating notification preferences:", error)
    res.status(500).json({ message: "Server error", error: error.message })
  }
}


import express from "express"
import { asyncHandler } from "../utils/asyncHandler.js"
import { authMiddleware } from "../middleware/auth.js"
import {
  register,
  login,
  verifyOTP,
  resendOTP,
  logout,
  getCurrentUser,
  forgotPassword,
  resetPassword,
  changePassword,
} from "../controllers/authController.js"

const router = express.Router()

// Public routes
router.post("/register", asyncHandler(register))
router.post("/login", asyncHandler(login))
router.post("/verify-otp", asyncHandler(verifyOTP))
router.post("/resend-otp", asyncHandler(resendOTP))
router.post("/forgot-password", asyncHandler(forgotPassword))
router.post("/reset-password", asyncHandler(resetPassword))

// Protected routes
router.use(authMiddleware)
router.get("/me", asyncHandler(getCurrentUser))
router.post("/logout", asyncHandler(logout))
router.post("/change-password", asyncHandler(changePassword))

export default router


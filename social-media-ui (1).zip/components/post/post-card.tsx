"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { formatDistanceToNow } from "date-fns"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuCheckboxItem,
} from "@/components/ui/dropdown-menu"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import {
  Heart,
  MessageCircle,
  MoreHorizontal,
  Repeat,
  Bookmark,
  Flag,
  Trash,
  Share,
  Copy,
  VolumeX,
  EyeOff,
  FolderPlus,
  Check,
} from "lucide-react"
import { cn } from "@/lib/utils"

interface PostCardProps {
  post: any
  isCurrentUser?: boolean
  isBookmarked?: boolean
  onRemoveBookmark?: () => void
  collections?: string[]
}

export function PostCard({
  post,
  isCurrentUser = false,
  isBookmarked = false,
  onRemoveBookmark,
  collections = [],
}: PostCardProps) {
  const [liked, setLiked] = useState(false)
  const [likeCount, setLikeCount] = useState(post.likes)
  const [reposted, setReposted] = useState(false)
  const [repostCount, setRepostCount] = useState(post.reposts)
  const [saved, setSaved] = useState(isBookmarked)
  const [showDeleteDialog, setShowDeleteDialog] = useState(false)
  const [postCollections, setPostCollections] = useState<string[]>(post.collections || [])

  const handleLike = () => {
    if (liked) {
      setLikeCount((prev) => prev - 1)
    } else {
      setLikeCount((prev) => prev + 1)
    }
    setLiked(!liked)
  }

  const handleRepost = () => {
    if (reposted) {
      setRepostCount((prev) => prev - 1)
    } else {
      setRepostCount((prev) => prev + 1)
    }
    setReposted(!reposted)
  }

  const handleSave = () => {
    setSaved(!saved)
    if (saved && onRemoveBookmark) {
      onRemoveBookmark()
    }
  }

  const handleDelete = () => {
    // In a real app, we would call an API to delete the post
    console.log("Deleting post:", post.id)
    setShowDeleteDialog(false)
  }

  const toggleCollection = (collection: string) => {
    if (postCollections.includes(collection)) {
      setPostCollections(postCollections.filter((c) => c !== collection))
    } else {
      setPostCollections([...postCollections, collection])
    }
  }

  const copyPostLink = () => {
    navigator.clipboard.writeText(`https://socialsphere.com/post/${post.id}`)
    // Show toast notification in a real app
    alert("Post link copied to clipboard!")
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-start space-y-0 pb-2">
        <Link href={`/profile/${post.author.username}`} className="flex items-center space-x-4">
          <Avatar>
            <AvatarImage src={post.author.avatar} alt={post.author.name} />
            <AvatarFallback>{post.author.name.charAt(0)}</AvatarFallback>
          </Avatar>
          <div className="space-y-1">
            <div className="flex items-center">
              <span className="font-semibold">{post.author.name}</span>
              <span className="ml-2 text-sm text-muted-foreground">@{post.author.username}</span>
              <span className="mx-1 text-muted-foreground">·</span>
              <span className="text-sm text-muted-foreground">
                {formatDistanceToNow(new Date(post.createdAt), { addSuffix: true })}
              </span>
            </div>
          </div>
        </Link>
        <div className="ml-auto">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="rounded-full">
                <MoreHorizontal className="h-4 w-4" />
                <span className="sr-only">More options</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={handleSave}>
                <Bookmark className={cn("mr-2 h-4 w-4", saved && "fill-current")} />
                {saved ? "Remove from bookmarks" : "Save"}
              </DropdownMenuItem>

              {saved && collections.length > 0 && (
                <DropdownMenuSub>
                  <DropdownMenuSubTrigger>
                    <FolderPlus className="mr-2 h-4 w-4" />
                    <span>Add to collection</span>
                  </DropdownMenuSubTrigger>
                  <DropdownMenuSubContent>
                    {collections.map((collection) => (
                      <DropdownMenuCheckboxItem
                        key={collection}
                        checked={postCollections.includes(collection)}
                        onCheckedChange={() => toggleCollection(collection)}
                      >
                        {collection}
                        {postCollections.includes(collection) && <Check className="ml-auto h-4 w-4" />}
                      </DropdownMenuCheckboxItem>
                    ))}
                  </DropdownMenuSubContent>
                </DropdownMenuSub>
              )}

              <DropdownMenuItem onClick={copyPostLink}>
                <Copy className="mr-2 h-4 w-4" />
                Copy link
              </DropdownMenuItem>

              <DropdownMenuItem>
                <Share className="mr-2 h-4 w-4" />
                Share via...
              </DropdownMenuItem>

              <DropdownMenuSeparator />

              {isCurrentUser ? (
                <>
                  <DropdownMenuItem
                    onClick={() => setShowDeleteDialog(true)}
                    className="text-red-500 focus:text-red-500"
                  >
                    <Trash className="mr-2 h-4 w-4" />
                    Delete
                  </DropdownMenuItem>
                </>
              ) : (
                <>
                  <DropdownMenuItem>
                    <Flag className="mr-2 h-4 w-4" />
                    Report
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem>
                    <VolumeX className="mr-2 h-4 w-4" />
                    Mute @{post.author.username}
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <EyeOff className="mr-2 h-4 w-4" />
                    Not interested in this post
                  </DropdownMenuItem>
                </>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </CardHeader>
      <CardContent className="pb-2">
        <Link href={`/post/${post.id}`}>
          <p className="whitespace-pre-line">{post.content}</p>
          {post.image && (
            <div className="mt-3 overflow-hidden rounded-lg">
              <Image
                src={post.image || "/placeholder.svg"}
                alt="Post image"
                width={500}
                height={300}
                className="h-auto w-full object-cover"
              />
            </div>
          )}
        </Link>
      </CardContent>
      <CardFooter className="flex justify-between pt-2">
        <Button variant="ghost" size="sm" className="rounded-full text-muted-foreground" asChild>
          <Link href={`/post/${post.id}`}>
            <MessageCircle className="mr-1 h-4 w-4" />
            {post.comments}
          </Link>
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className={`rounded-full ${reposted ? "text-green-500" : "text-muted-foreground"}`}
          onClick={handleRepost}
        >
          <Repeat className="mr-1 h-4 w-4" />
          {repostCount}
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className={`rounded-full ${liked ? "text-red-500" : "text-muted-foreground"}`}
          onClick={handleLike}
        >
          <Heart className="mr-1 h-4 w-4" fill={liked ? "currentColor" : "none"} />
          {likeCount}
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className={`rounded-full ${saved ? "text-blue-500" : "text-muted-foreground"}`}
          onClick={handleSave}
        >
          <Bookmark className="mr-1 h-4 w-4" fill={saved ? "currentColor" : "none"} />
          Save
        </Button>
      </CardFooter>

      {/* Delete Post Dialog */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Post</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this post? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-500 hover:bg-red-600">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  )
}


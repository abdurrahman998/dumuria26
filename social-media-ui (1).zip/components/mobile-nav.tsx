"use client"

import * as React from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import {
  Menu,
  Home,
  Search,
  MessageSquare,
  Bell,
  Bookmark,
  User,
  Settings,
  LogOut,
  PaintbrushIcon as PaintBrush,
} from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Separator } from "@/components/ui/separator"

export function MobileNav() {
  const [open, setOpen] = React.useState(false)
  const pathname = usePathname()

  const routes = [
    {
      href: "/feed",
      label: "Home",
      icon: <Home className="h-5 w-5 mr-3" />,
      active: pathname === "/feed",
    },
    {
      href: "/search",
      label: "Search",
      icon: <Search className="h-5 w-5 mr-3" />,
      active: pathname === "/search",
    },
    {
      href: "/messages",
      label: "Messages",
      icon: <MessageSquare className="h-5 w-5 mr-3" />,
      active: pathname.startsWith("/messages"),
    },
    {
      href: "/notifications",
      label: "Notifications",
      icon: <Bell className="h-5 w-5 mr-3" />,
      active: pathname === "/notifications",
    },
    {
      href: "/bookmarks",
      label: "Bookmarks",
      icon: <Bookmark className="h-5 w-5 mr-3" />,
      active: pathname === "/bookmarks",
    },
    {
      href: "/profile/johndoe",
      label: "Profile",
      icon: <User className="h-5 w-5 mr-3" />,
      active: pathname.startsWith("/profile"),
    },
    {
      href: "/settings",
      label: "Settings",
      icon: <Settings className="h-5 w-5 mr-3" />,
      active: pathname === "/settings",
    },
  ]

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" className="md:hidden">
          <Menu className="h-5 w-5" />
          <span className="sr-only">Toggle menu</span>
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="flex flex-col p-0">
        <SheetHeader className="p-4 border-b">
          <SheetTitle className="flex items-center">
            <div className="flex items-center space-x-2">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-6 w-6 text-primary"
              >
                <path d="M15 6v12a3 3 0 1 0 3-3H6a3 3 0 1 0 3 3V6a3 3 0 1 0-3 3h12a3 3 0 1 0-3-3" />
              </svg>
              <span className="font-bold text-xl">SocialSphere</span>
            </div>
          </SheetTitle>
        </SheetHeader>

        <div className="px-2 py-4">
          <div className="flex items-center px-3 py-2 mb-4">
            <Avatar className="h-10 w-10 mr-3">
              <AvatarImage src="/placeholder.svg?height=40&width=40" alt="@user" />
              <AvatarFallback>JD</AvatarFallback>
            </Avatar>
            <div>
              <p className="font-medium">John Doe</p>
              <p className="text-sm text-muted-foreground">@johndoe</p>
            </div>
          </div>

          <nav className="space-y-1">
            {routes.map((route) => (
              <Link
                key={route.href}
                href={route.href}
                onClick={() => setOpen(false)}
                className={cn(
                  "flex items-center px-3 py-2 rounded-md text-sm transition-colors",
                  route.active
                    ? "bg-primary/10 text-primary font-medium"
                    : "hover:bg-accent hover:text-accent-foreground",
                )}
              >
                {route.icon}
                {route.label}
              </Link>
            ))}
          </nav>

          <Separator className="my-4" />

          <div className="px-3 py-2">
            <Button
              variant="ghost"
              className="w-full justify-start text-sm font-normal"
              onClick={() => {
                // Open theme customizer
                const themeButton = document.querySelector('[data-theme-customizer-trigger="true"]')
                if (themeButton) {
                  ;(themeButton as HTMLButtonElement).click()
                }
                setOpen(false)
              }}
            >
              <PaintBrush className="h-5 w-5 mr-3" />
              Customize Theme
            </Button>

            <Link href="/login" onClick={() => setOpen(false)}>
              <Button variant="ghost" className="w-full justify-start text-sm font-normal mt-1">
                <LogOut className="h-5 w-5 mr-3" />
                Sign Out
              </Button>
            </Link>
          </div>
        </div>

        <div className="mt-auto p-4 text-xs text-center text-muted-foreground">
          <p>© 2025 SocialSphere</p>
          <div className="flex justify-center space-x-3 mt-2">
            <Link href="/terms" className="hover:underline">
              Terms
            </Link>
            <Link href="/privacy" className="hover:underline">
              Privacy
            </Link>
            <Link href="/help" className="hover:underline">
              Help
            </Link>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  )
}


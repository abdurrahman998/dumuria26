"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Icons } from "@/components/icons"

interface EditProfileFormProps {
  user: any
}

export function EditProfileForm({ user }: EditProfileFormProps) {
  const router = useRouter()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [activeTab, setActiveTab] = useState("profile")
  const [formData, setFormData] = useState({
    name: user.name,
    username: user.username,
    bio: user.bio,
    location: user.location,
    website: user.website,
    facebook: "",
    twitter: "",
    instagram: "",
    linkedin: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false)
      router.push(`/profile/${user.username}`)
    }, 1000)
  }

  return (
    <form onSubmit={handleSubmit}>
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList>
          <TabsTrigger value="profile">Profile</TabsTrigger>
          <TabsTrigger value="social">Social Links</TabsTrigger>
          <TabsTrigger value="privacy">Privacy</TabsTrigger>
        </TabsList>

        <TabsContent value="profile" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Profile Information</CardTitle>
              <CardDescription>Update your profile information visible to other users.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label>Profile Picture</Label>
                <div className="flex items-center space-x-4">
                  <Avatar className="h-20 w-20">
                    <AvatarImage src={user.avatar} alt={user.name} />
                    <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <Button variant="outline" size="sm">
                      Change
                    </Button>
                    <p className="mt-2 text-xs text-muted-foreground">JPG, GIF or PNG. 1MB max.</p>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Cover Photo</Label>
                <div className="relative h-40 w-full overflow-hidden rounded-lg border">
                  <img src={user.coverImage || "/placeholder.svg"} alt="Cover" className="h-full w-full object-cover" />
                  <div className="absolute bottom-2 right-2">
                    <Button variant="secondary" size="sm">
                      Change
                    </Button>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="name">Name</Label>
                <Input id="name" name="name" value={formData.name} onChange={handleChange} />
              </div>

              <div className="space-y-2">
                <Label htmlFor="username">Username</Label>
                <Input id="username" name="username" value={formData.username} onChange={handleChange} />
              </div>

              <div className="space-y-2">
                <Label htmlFor="bio">Bio</Label>
                <Textarea id="bio" name="bio" value={formData.bio} onChange={handleChange} rows={4} />
              </div>

              <div className="space-y-2">
                <Label htmlFor="location">Location</Label>
                <Input id="location" name="location" value={formData.location} onChange={handleChange} />
              </div>

              <div className="space-y-2">
                <Label htmlFor="website">Website</Label>
                <Input id="website" name="website" value={formData.website} onChange={handleChange} />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="social" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Social Links</CardTitle>
              <CardDescription>Connect your social media accounts to your profile.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="facebook">Facebook</Label>
                <Input
                  id="facebook"
                  name="facebook"
                  placeholder="https://facebook.com/username"
                  value={formData.facebook}
                  onChange={handleChange}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="twitter">Twitter</Label>
                <Input
                  id="twitter"
                  name="twitter"
                  placeholder="https://twitter.com/username"
                  value={formData.twitter}
                  onChange={handleChange}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="instagram">Instagram</Label>
                <Input
                  id="instagram"
                  name="instagram"
                  placeholder="https://instagram.com/username"
                  value={formData.instagram}
                  onChange={handleChange}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="linkedin">LinkedIn</Label>
                <Input
                  id="linkedin"
                  name="linkedin"
                  placeholder="https://linkedin.com/in/username"
                  value={formData.linkedin}
                  onChange={handleChange}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="privacy" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Privacy Settings</CardTitle>
              <CardDescription>Control who can see your profile and content.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <input type="checkbox" id="privateAccount" className="h-4 w-4" />
                  <div>
                    <Label htmlFor="privateAccount">Private Account</Label>
                    <p className="text-sm text-muted-foreground">
                      Only approved followers can see your posts and profile information.
                    </p>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <input type="checkbox" id="hideLocation" className="h-4 w-4" />
                  <div>
                    <Label htmlFor="hideLocation">Hide Location</Label>
                    <p className="text-sm text-muted-foreground">Don't show your location on your profile.</p>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <input type="checkbox" id="hideActivity" className="h-4 w-4" />
                  <div>
                    <Label htmlFor="hideActivity">Hide Activity Status</Label>
                    <p className="text-sm text-muted-foreground">Don't show when you're active on the platform.</p>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <input type="checkbox" id="allowTagging" className="h-4 w-4" defaultChecked />
                  <div>
                    <Label htmlFor="allowTagging">Allow Tagging</Label>
                    <p className="text-sm text-muted-foreground">
                      Allow others to tag you in their posts and comments.
                    </p>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="whoCanMessage">Who can message you</Label>
                <select id="whoCanMessage" className="w-full rounded-md border border-input bg-background px-3 py-2">
                  <option value="everyone">Everyone</option>
                  <option value="followers">Followers only</option>
                  <option value="nobody">Nobody</option>
                </select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="whoCanComment">Who can comment on your posts</Label>
                <select id="whoCanComment" className="w-full rounded-md border border-input bg-background px-3 py-2">
                  <option value="everyone">Everyone</option>
                  <option value="followers">Followers only</option>
                  <option value="nobody">Nobody</option>
                </select>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="mt-6 flex justify-end space-x-2">
        <Button type="button" variant="outline" onClick={() => router.push(`/profile/${user.username}`)}>
          Cancel
        </Button>
        <Button type="submit" disabled={isSubmitting}>
          {isSubmitting && <Icons.spinner className="mr-2 h-4 w-4 animate-spin" />}
          Save Changes
        </Button>
      </div>
    </form>
  )
}


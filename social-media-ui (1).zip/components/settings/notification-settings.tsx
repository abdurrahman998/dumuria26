"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Icons } from "@/components/icons"

export function NotificationSettings() {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [settings, setSettings] = useState({
    likes: true,
    comments: true,
    mentions: true,
    follows: true,
    directMessages: true,
    newFeatures: false,
    emailNotifications: true,
    pushNotifications: true,
  })

  const handleToggle = (name: string) => {
    setSettings((prev) => ({ ...prev, [name]: !prev[name as keyof typeof prev] }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false)
    }, 1000)
  }

  return (
    <form onSubmit={handleSubmit}>
      <Card>
        <CardHeader>
          <CardTitle>Notifications</CardTitle>
          <CardDescription>Manage your notification preferences.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <h3 className="mb-4 text-lg font-medium">Activity Notifications</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="likes">Likes</Label>
                <Switch id="likes" checked={settings.likes} onCheckedChange={() => handleToggle("likes")} />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="comments">Comments</Label>
                <Switch id="comments" checked={settings.comments} onCheckedChange={() => handleToggle("comments")} />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="mentions">Mentions</Label>
                <Switch id="mentions" checked={settings.mentions} onCheckedChange={() => handleToggle("mentions")} />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="follows">Follows</Label>
                <Switch id="follows" checked={settings.follows} onCheckedChange={() => handleToggle("follows")} />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="directMessages">Direct Messages</Label>
                <Switch
                  id="directMessages"
                  checked={settings.directMessages}
                  onCheckedChange={() => handleToggle("directMessages")}
                />
              </div>
            </div>
          </div>

          <div>
            <h3 className="mb-4 text-lg font-medium">Other Notifications</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="newFeatures">New Features</Label>
                <Switch
                  id="newFeatures"
                  checked={settings.newFeatures}
                  onCheckedChange={() => handleToggle("newFeatures")}
                />
              </div>
            </div>
          </div>

          <div>
            <h3 className="mb-4 text-lg font-medium">Notification Methods</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="emailNotifications">Email Notifications</Label>
                <Switch
                  id="emailNotifications"
                  checked={settings.emailNotifications}
                  onCheckedChange={() => handleToggle("emailNotifications")}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="pushNotifications">Push Notifications</Label>
                <Switch
                  id="pushNotifications"
                  checked={settings.pushNotifications}
                  onCheckedChange={() => handleToggle("pushNotifications")}
                />
              </div>
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting && <Icons.spinner className="mr-2 h-4 w-4 animate-spin" />}
            Save Changes
          </Button>
        </CardFooter>
      </Card>
    </form>
  )
}


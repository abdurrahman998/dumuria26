"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar, LinkIcon, MapPin, MoreHorizontal, MessageSquare, Flag, Edit, Lock } from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { SavedPosts } from "@/components/user/saved-posts"
import { UserAnalytics } from "@/components/user/user-analytics"

interface UserProfileProps {
  user: any
  isCurrentUser?: boolean
}

export function UserProfile({ user, isCurrentUser = false }: UserProfileProps) {
  const [isFollowing, setIsFollowing] = useState(false)
  const [showReportDialog, setShowReportDialog] = useState(false)
  const [reportReason, setReportReason] = useState("")

  const handleFollow = () => {
    setIsFollowing(!isFollowing)
  }

  const handleReport = () => {
    // In a real app, we would send the report to the server
    console.log("Report submitted:", reportReason)
    setShowReportDialog(false)
    setReportReason("")
  }

  return (
    <Card>
      <div className="relative h-48 w-full overflow-hidden sm:h-64">
        <Image
          src={user.coverImage || "/placeholder.svg?height=400&width=1200"}
          alt="Cover"
          fill
          className="object-cover"
        />
      </div>
      <CardContent className="relative pt-0">
        <div className="flex flex-col items-start sm:flex-row sm:justify-between">
          <div className="-mt-12 flex flex-col items-center sm:flex-row sm:items-end sm:space-x-5">
            <Avatar className="h-24 w-24 border-4 border-background sm:h-32 sm:w-32">
              <AvatarImage src={user.avatar} alt={user.name} />
              <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <div className="mt-4 text-center sm:mt-0 sm:text-left">
              <h1 className="text-2xl font-bold">{user.name}</h1>
              <p className="text-muted-foreground">@{user.username}</p>
            </div>
          </div>
          <div className="mt-4 flex w-full gap-2 sm:mt-0 sm:w-auto">
            {isCurrentUser ? (
              <>
                <Button variant="outline" asChild>
                  <Link href="/profile/edit">
                    <Edit className="mr-2 h-4 w-4" />
                    Edit Profile
                  </Link>
                </Button>
              </>
            ) : (
              <>
                <Button variant={isFollowing ? "outline" : "default"} onClick={handleFollow}>
                  {isFollowing ? "Following" : "Follow"}
                </Button>
                <Button variant="outline" asChild>
                  <Link href={`/messages/new?username=${user.username}`}>
                    <MessageSquare className="mr-2 h-4 w-4" />
                    Message
                  </Link>
                </Button>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon">
                      <MoreHorizontal className="h-5 w-5" />
                      <span className="sr-only">More options</span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onSelect={() => setShowReportDialog(true)}>
                      <Flag className="mr-2 h-4 w-4" />
                      Report Profile
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem>
                      <Lock className="mr-2 h-4 w-4" />
                      Block User
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            )}
          </div>
        </div>

        <div className="mt-6">
          <p className="whitespace-pre-line">{user.bio}</p>

          <div className="mt-4 flex flex-wrap gap-y-2">
            {user.location && (
              <div className="mr-4 flex items-center text-muted-foreground">
                <MapPin className="mr-1 h-4 w-4" />
                {user.location}
              </div>
            )}
            {user.website && (
              <div className="mr-4 flex items-center text-muted-foreground">
                <LinkIcon className="mr-1 h-4 w-4" />
                <a
                  href={user.website}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary hover:underline"
                >
                  {user.website.replace(/^https?:\/\//, "")}
                </a>
              </div>
            )}
            {user.joinedAt && (
              <div className="flex items-center text-muted-foreground">
                <Calendar className="mr-1 h-4 w-4" />
                Joined {new Date(user.joinedAt).toLocaleDateString("en-US", { month: "long", year: "numeric" })}
              </div>
            )}
          </div>

          <div className="mt-4 flex space-x-4">
            <div>
              <span className="font-semibold">{user.following}</span>{" "}
              <span className="text-muted-foreground">Following</span>
            </div>
            <div>
              <span className="font-semibold">{user.followers}</span>{" "}
              <span className="text-muted-foreground">Followers</span>
            </div>
          </div>
        </div>

        <Tabs defaultValue="posts" className="mt-6">
          <TabsList className="w-full justify-start">
            <TabsTrigger value="posts">Posts</TabsTrigger>
            <TabsTrigger value="replies">Replies</TabsTrigger>
            <TabsTrigger value="media">Media</TabsTrigger>
            <TabsTrigger value="likes">Likes</TabsTrigger>
            {isCurrentUser && (
              <>
                <TabsTrigger value="saved">Saved</TabsTrigger>
                <TabsTrigger value="analytics">Analytics</TabsTrigger>
              </>
            )}
          </TabsList>

          {isCurrentUser && (
            <>
              <TabsContent value="saved">
                <SavedPosts />
              </TabsContent>
              <TabsContent value="analytics">
                <UserAnalytics />
              </TabsContent>
            </>
          )}
        </Tabs>
      </CardContent>

      {/* Report Dialog */}
      <Dialog open={showReportDialog} onOpenChange={setShowReportDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Report @{user.username}</DialogTitle>
            <DialogDescription>
              Please select a reason for reporting this profile. Your report will be reviewed by our moderation team.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <input
                  type="radio"
                  id="spam"
                  name="reportReason"
                  value="spam"
                  checked={reportReason === "spam"}
                  onChange={(e) => setReportReason(e.target.value)}
                  className="h-4 w-4"
                />
                <label htmlFor="spam">Spam</label>
              </div>
              <div className="flex items-center space-x-2">
                <input
                  type="radio"
                  id="harassment"
                  name="reportReason"
                  value="harassment"
                  checked={reportReason === "harassment"}
                  onChange={(e) => setReportReason(e.target.value)}
                  className="h-4 w-4"
                />
                <label htmlFor="harassment">Harassment</label>
              </div>
              <div className="flex items-center space-x-2">
                <input
                  type="radio"
                  id="inappropriate"
                  name="reportReason"
                  value="inappropriate"
                  checked={reportReason === "inappropriate"}
                  onChange={(e) => setReportReason(e.target.value)}
                  className="h-4 w-4"
                />
                <label htmlFor="inappropriate">Inappropriate content</label>
              </div>
              <div className="flex items-center space-x-2">
                <input
                  type="radio"
                  id="impersonation"
                  name="reportReason"
                  value="impersonation"
                  checked={reportReason === "impersonation"}
                  onChange={(e) => setReportReason(e.target.value)}
                  className="h-4 w-4"
                />
                <label htmlFor="impersonation">Impersonation</label>
              </div>
              <div className="flex items-center space-x-2">
                <input
                  type="radio"
                  id="other"
                  name="reportReason"
                  value="other"
                  checked={reportReason === "other"}
                  onChange={(e) => setReportReason(e.target.value)}
                  className="h-4 w-4"
                />
                <label htmlFor="other">Other</label>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowReportDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleReport} disabled={!reportReason}>
              Submit Report
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  )
}


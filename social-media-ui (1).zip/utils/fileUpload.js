import multer from "multer"
import path from "path"
import fs from "fs"
import { v4 as uuidv4 } from "uuid"
import { ApiError } from "./ApiError.js"
import sharp from "sharp"

// Create uploads directory if it doesn't exist
const createUploadsDir = () => {
  const uploadsDir = path.join(process.cwd(), "uploads")
  if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true })
  }

  // Create subdirectories
  const dirs = ["posts", "profiles", "messages", "temp"]
  dirs.forEach((dir) => {
    const dirPath = path.join(uploadsDir, dir)
    if (!fs.existsSync(dirPath)) {
      fs.mkdirSync(dirPath, { recursive: true })
    }
  })

  return uploadsDir
}

const uploadsDir = createUploadsDir()

// Configure multer storage
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    // Determine destination folder based on file type or route
    let folder = "temp"

    if (req.baseUrl.includes("/posts")) {
      folder = "posts"
    } else if (req.baseUrl.includes("/users")) {
      folder = "profiles"
    } else if (req.baseUrl.includes("/messages")) {
      folder = "messages"
    }

    const destination = path.join(uploadsDir, folder)
    cb(null, destination)
  },
  filename: (req, file, cb) => {
    // Generate unique filename
    const uniqueSuffix = uuidv4()
    const extension = path.extname(file.originalname)
    cb(null, `${uniqueSuffix}${extension}`)
  },
})

// File filter function
const fileFilter = (req, file, cb) => {
  // Allowed file types
  const allowedImageTypes = ["image/jpeg", "image/png", "image/gif", "image/webp"]
  const allowedVideoTypes = ["video/mp4", "video/webm", "video/quicktime"]
  const allowedAudioTypes = ["audio/mpeg", "audio/wav", "audio/ogg"]
  const allowedFileTypes = [
    ...allowedImageTypes,
    ...allowedVideoTypes,
    ...allowedAudioTypes,
    "application/pdf",
    "application/msword",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/vnd.ms-excel",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "text/plain",
  ]

  if (allowedFileTypes.includes(file.mimetype)) {
    cb(null, true)
  } else {
    cb(new ApiError(400, "File type not allowed"), false)
  }
}

// Configure multer upload
export const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: 50 * 1024 * 1024, // 50MB max file size
  },
})

// Process uploaded image
export const processImage = async (filePath, options = {}) => {
  const { width = 1200, height = 1200, quality = 80 } = options

  try {
    const processedImagePath = filePath.replace(/\.\w+$/, "_processed.jpg")

    await sharp(filePath)
      .resize(width, height, { fit: "inside", withoutEnlargement: true })
      .jpeg({ quality })
      .toFile(processedImagePath)

    // Replace original with processed image
    fs.unlinkSync(filePath)
    fs.renameSync(processedImagePath, filePath)

    return filePath
  } catch (error) {
    console.error("Error processing image:", error)
    return filePath
  }
}

// Get file URL
export const getFileUrl = (filePath) => {
  // In production, this would be your CDN or server URL
  const baseUrl = process.env.BASE_URL || `http://localhost:${process.env.PORT || 5000}`
  const relativePath = filePath.replace(process.cwd(), "")
  return `${baseUrl}${relativePath.replace(/\\/g, "/")}`
}

// Delete file
export const deleteFile = (filePath) => {
  try {
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath)
      return true
    }
    return false
  } catch (error) {
    console.error("Error deleting file:", error)
    return false
  }
}

